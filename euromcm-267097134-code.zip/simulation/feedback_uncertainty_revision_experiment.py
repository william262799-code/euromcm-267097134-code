"""Finite-feedback learning, uncertainty, and revision mechanism experiment.

Conditional synthetic extension to the frozen v5 case. Latent quality is keyed
and generated before routing, but is written only to the evaluator audit file.
The router consumes verifier/user feedback from completed prior batches only.
"""
import argparse, csv, hashlib, json, math, random
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'simulation/public_ci_joint_v5_scenarios.json'
CI_DATA=ROOT/'data_public/neso_2026_10_09_to_16/regional_forecast.csv'
OUT_DEFAULT=ROOT/'results/feedback_uncertainty_revision_v5'
SEED=20261018
POLICIES=(
 'always_small','always_large','feedback_mean','feedback_lcb','feedback_no_verifier',
 'direct_small','revise_once','revise_multi','combined',
 'combined_no_learning','combined_no_uncertainty','combined_no_revision')

def keyed(seed,*parts):
    s='|'.join(map(str,(seed,*parts))).encode()
    return random.Random(int.from_bytes(hashlib.blake2b(s,digest_size=8).digest(),'big'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write_csv(path,rows):
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def wilson_lower(successes,n,z=1.645):
    if n==0:return 0.0
    p=successes/n;den=1+z*z/n
    return max(0.,(p+z*z/(2*n)-z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)))/den)

def run(out,seed):
    cfg=json.loads(BASE.read_text()); prof=cfg['actions']; gate=.75; out=Path(out);out.mkdir(parents=True,exist_ok=True)
    with CI_DATA.open(newline='',encoding='utf-8') as f: ci_rows=list(csv.DictReader(f))
    ci_by_region={'London':[float(x['forecast_gco2_per_kwh']) for x in sorted((x for x in ci_rows if x['regionid']=='13' and x['region']=='London'),key=lambda x:x['from_utc'])],
                  'Wales':[float(x['forecast_gco2_per_kwh']) for x in sorted((x for x in ci_rows if x['regionid']=='17' and x['region']=='Wales'),key=lambda x:x['from_utc'])]}
    assert len(ci_by_region['London'])==len(ci_by_region['Wales'])==336
    axes=[]
    for load in (3,6):
      for qshift in (-.04,0.,.04):
       for fa,fr in ((.05,.05),(.20,.05),(.02,.10)):
        for large_cost in (1.,1.5):
         for rev_gain in (.08,.16): axes.append(dict(load_per_slot=load,quality_shift=qshift,FA=fa,FR=fr,large_cost_multiplier=large_cost,revision_gain=rev_gain))
    assumptions={'claim':'conditional synthetic mechanism test; not deployment evidence','seed':seed,
      'router_observables':['request difficulty bin','completed-stage verifier pass/fail','noisy user dissatisfaction','observed service time and cost'],
      'router_forbidden':['latent quality','true quality pass','future feedback','potential outcomes for unchosen actions'],
      'quality_generator':'pre-generated per request, action, attempt using keyed random draws; evaluator-only; small/large profiles inherited from frozen v5 synthetic scenario file',
      'feedback':'verifier result is observed at batch end; user mark is generated only after a completed answer and is a noisy label of failure; updates affect later batches only',
      'posterior':'Beta(3,1) declared synthetic prior on observed pass probability per difficulty-bin × action; point estimate inverted using declared verifier FA/FR (or separate 10% user-mark error in the no-verifier ablation); conservative policy uses Wilson 90% lower bound then the same inversion',
      'exploration':'10% seeded request-level exploration assigns the small action for adaptive policies, including the no-learning ablation, to ensure observable feedback for that action; this is a synthetic design choice, not a safe deployment prescription',
      'resources':'synthetic server-work budget 2 servers × 1800 s per region and 1800 s deadline; service times, energy and cost inherited from frozen v5 scenario; aggregate work within each half-hour batch, no overlap claims beyond this batch budget',
      'revision':'after observed verifier failure or user dissatisfaction only; a revision reruns large action; multi allows at most 2 revisions; each consumes full configured time/energy/cost; quality can improve with declared probability/gain, remain unchanged otherwise; no router access to resulting truth',
      'limits':['Synthetic parameters and one seed; no empirical calibration.','Aggregate within-batch capacity approximation, not exact continuous queue scheduling.','Grid carbon uses archived paired NESO forecast at request-slot midpoint and v5 PUE scenario 1.45.'],
      'axes':axes,'sensitivity_axes':{'load_per_slot':[3,6],'quality_shift':[-.04,0,.04],'FA_FR':[[.05,.05],[.20,.05],[.02,.10]],'large_cost_multiplier':[1.,1.5],'revision_gain':[.08,.16]},'policies':list(POLICIES)}
    (out/'scenario_config.json').write_text(json.dumps(assumptions,indent=2)+'\n')
    all_summary=[]; all_logs=[]; all_audit=[]; all_feedback=[]
    for ai,sc in enumerate(axes):
      # Identical request stream and pre-generated potential quality across policies.
      reqs=[]
      for slot in range(336):
        for j in range(sc['load_per_slot']):
          rid=f's{slot:03d}_r{j}';rng=keyed(seed,'request',rid)
          d=rng.random();home='London' if rng.random()<.5 else 'Wales'
          reqs.append(dict(rid=rid,slot=slot,d=d,bin='low' if d<.5 else 'high',home=home))
      latent={}
      for r in reqs:
        for action in ('small','large'):
          p=prof[action];mu=max(0,min(1,p['quality_intercept']+sc['quality_shift']-p['quality_difficulty_slope']*r['d']))
          for attempt in range(3):
            q=max(0,min(1,keyed(seed,ai,r['rid'],action,attempt,'quality').gauss(mu,p['quality_noise_sd'])))
            latent[(r['rid'],action,attempt)]=q
      for pol in POLICIES:
        # Counts are router-owned; no simulator truth enters these objects.
        counts={(b,a):[3,1] for b in ('low','high') for a in ('small','large')}
        batch_feedback=[]; region_work={'London':0.,'Wales':0.}; batch_num=-1
        rows=[]; valid=0; served=0; total_cost=total_energy=total_carbon=0.; revisions=revision_success=0; deadlines=0; capacity_blocks=0; believed_pass=believed_false=0; escalations=0; responses=[]
        for r in reqs:
          if r['slot']!=batch_num:
            # Only outcomes completed before this batch are now visible.
            for fb in batch_feedback:
              if fb['signal'] is not None:
                c=counts[(fb['bin'],fb['action'])]; c[0]+=int(fb['signal']);c[1]+=int(not fb['signal'])
            batch_feedback=[];batch_num=r['slot'];region_work={'London':0.,'Wales':0.}
          def estimate(action):
            s,n=counts[(r['bin'],action)]; raw=s/(s+n)
            lo=wilson_lower(s,s+n)
            fa,fr=(.1,.1) if pol=='feedback_no_verifier' else (sc['FA'],sc['FR'])
            return max(0,min(1,(raw-fa)/(1-fa-fr))),max(0,min(1,(lo-fa)/(1-fa-fr)))
          if pol in ('always_large',): action='large'
          elif pol in ('always_small','direct_small','revise_once','revise_multi'): action='small'
          elif pol=='feedback_no_verifier':
            # This ablation learns only from noisy user marks, not verifier outcomes.
            action='small' if estimate('small')[0]>=gate else 'large'
          elif pol=='feedback_mean' or pol=='combined_no_uncertainty': action='small' if estimate('small')[0]>=gate else 'large'
          elif pol in ('feedback_lcb','combined','combined_no_learning','combined_no_revision'):
            action='small' if estimate('small')[1]>=gate else 'large'
          else: action='small'
          adaptive={'feedback_mean','feedback_lcb','feedback_no_verifier','combined','combined_no_learning','combined_no_uncertainty','combined_no_revision'}
          explore=(pol in adaptive and keyed(seed,ai,r['rid'],'exploration').random()<.10)
          if explore:action='small'
          if action=='large':escalations+=1
          stage_actions=[]; current=action; qfinal=None; sig=None; dissatisfied=False; latency=0.; req_cost=req_energy=0.; blocked=False; blocked_reason=''
          maxrev=0 if pol in ('always_small','always_large','feedback_mean','feedback_lcb','feedback_no_verifier','direct_small','combined_no_revision') else (2 if pol=='revise_multi' else 1)
          use_verifier=pol not in ('always_small','always_large','feedback_no_verifier','direct_small')
          # Aggregate finite capacity: each batch has 3,600 service seconds per region.
          for stage in range(maxrev+1):
            p=prof[current]; region=r['home']; duration=p['service_seconds']; work=region_work[region]
            wait=max(0.,work/2.)
            if work+duration>3600:
              blocked=True;blocked_reason='capacity';break
            if latency+wait+duration>1800:
              blocked=True;blocked_reason='deadline';break
            region_work[region]+=duration; latency+=wait+duration
            attempt=stage
            q=latent[(r['rid'],current,attempt)]
            # Revision transition is an explicit synthetic rule: 65% chance of
            # an improvement by the scenario gain, 25% unchanged, 10% regression.
            if stage>0:
              u=keyed(seed,ai,r['rid'],current,attempt,'revision_transition').random()
              if u<.65:q=min(1.,qfinal+sc['revision_gain'])
              elif u<.90:q=qfinal
              else:q=max(0.,qfinal-sc['revision_gain']/2)
            truth=q>=gate
            req_cost+=p['cost_units']*(sc['large_cost_multiplier'] if current=='large' else 1.);req_energy+=p['it_energy_kwh']
            verifier_pass=None
            if use_verifier:
              vr=keyed(seed,ai,r['rid'],current,attempt,'verifier').random()
              verifier_pass=vr < ((1-sc['FR']) if truth else sc['FA'])
              req_cost+=.02;req_energy+=.00002
              ur=keyed(seed,ai,r['rid'],current,attempt,'user').random()
              dissatisfied=(not truth if ur>=.1 else truth) # 90% accurate binary user signal
              signal=bool(verifier_pass)
            else:
              ur=keyed(seed,ai,r['rid'],current,attempt,'user').random()
              dissatisfied=(not truth if ur>=.1 else truth)
              signal=not dissatisfied
            stage_actions.append(dict(action=current,quality_truth=truth,quality=q,verifier_pass=verifier_pass,signal=signal,dissatisfied=dissatisfied))
            qfinal=q
            # delivery acceptance is governed by verifier when present, else direct delivery
            if not use_verifier or verifier_pass:
              # A noisy dissatisfaction mark can trigger revision even when
              # the verifier passed; in that case its signal arrives here.
              if stage<maxrev and dissatisfied:
                revisions+=1
                current='large'
                continue
              break
            if stage<maxrev:
              revisions+=1
              if current=='small':current='large'
              elif pol=='revise_multi':current='large'
          if stage_actions:
            last=stage_actions[-1];isserved=bool((last['verifier_pass'] is True or last['verifier_pass'] is None) and not blocked and latency<=1800)
            isvalid=bool(isserved and last['quality_truth'])
          else:isvalid=isserved=False
          if len(stage_actions)>1 and isvalid:revision_success+=1
          if blocked_reason=='capacity':capacity_blocks+=1
          if blocked_reason=='deadline' or latency>1800:deadlines+=1
          served+=int(isserved);valid+=int(isvalid)
          responses.append(latency)
          # source-backed hourly-series value is deliberately reported separately as a covariate.
          # Carbon uses the same explicit PUE and synthetic energy boundary as v5.
          ci=ci_by_region[r['home']][r['slot']]
          req_carbon=req_energy*1.45*ci
          total_cost+=req_cost;total_energy+=req_energy;total_carbon+=req_carbon
          est,low=estimate(action);router_believed=(est>=gate if pol in ('feedback_mean','feedback_no_verifier','combined_no_uncertainty') else low>=gate)
          believed_pass+=int(router_believed);believed_false+=int(router_believed and not isvalid)
          if stage_actions:
            # Updates become available only after this batch ends; fixed baselines do not learn.
            learn=pol in ('feedback_mean','feedback_lcb','feedback_no_verifier','combined','combined_no_uncertainty','combined_no_revision')
            if learn:
              for st in stage_actions:
                observed=st['signal'] if pol!='feedback_no_verifier' else (not st['dissatisfied'])
                batch_feedback.append(dict(bin=r['bin'],action=st['action'],signal=observed))
            for ix,st in enumerate(stage_actions):
              all_feedback.append(dict(scenario_id=f'x{ai:02d}',policy=pol,request_id=r['rid'],slot=r['slot'],difficulty_bin=r['bin'],stage=ix+1,action=st['action'],verifier_pass=st['verifier_pass'] if st['verifier_pass'] is not None else '',user_dissatisfied=st['dissatisfied'],feedback_available_after_stage=True,model_update_available_after_slot=r['slot']+1 if pol in ('feedback_mean','feedback_lcb','feedback_no_verifier','combined','combined_no_uncertainty','combined_no_revision') else 'never',synthetic_feedback=True))
            for ix,st in enumerate(stage_actions):
              all_audit.append(dict(scenario_id=f'x{ai:02d}',policy=pol,request_id=r['rid'],stage=ix+1,action=st['action'],region=r['home'],service_seconds=prof[st['action']]['service_seconds'],latent_quality=round(st['quality'],8),quality_pass=st['quality_truth'],verifier_pass=st['verifier_pass'],synthetic_latent_evaluator_only=True))
          small_mean,small_lcb=estimate('small')
          all_logs.append(dict(scenario_id=f'x{ai:02d}',policy=pol,request_id=r['rid'],slot=r['slot'],difficulty_bin=r['bin'],difficulty=r['d'],home_region=r['home'],grid_CI_g_per_kWh=ci,router_small_mean=round(small_mean,6),router_small_lcb=round(small_lcb,6),decision_estimate=round(est,6),decision_lcb=round(low,6),exploration=explore,chosen_action=action,router_feedback_available_through_slot=r['slot']-1,feedback_updated_after_slot=r['slot'],stages=len(stage_actions),revision_attempted=len(stage_actions)>1,observed_verifier=last['verifier_pass'] if stage_actions else '',observed_user_dissatisfied=last['dissatisfied'] if stage_actions else '',response_s=latency,cost=req_cost,energy_kWh=req_energy,carbon_g=req_carbon,capacity_blocked=blocked_reason=='capacity',deadline_met=not (blocked or latency>1800),served=isserved,valid=isvalid))
        n=len(reqs);all_summary.append(dict(scenario_id=f'x{ai:02d}',load_per_slot=sc['load_per_slot'],quality_shift=sc['quality_shift'],FA=sc['FA'],FR=sc['FR'],large_cost_multiplier=sc['large_cost_multiplier'],revision_gain=sc['revision_gain'],policy=pol,N_arrivals=n,N_served=served,N_valid=valid,valid_rate=valid/n,served_rate=served/n,system_cost_units=total_cost,cost_per_arrival=total_cost/n,cost_per_valid=total_cost/valid if valid else '',system_energy_kWh=total_energy,system_carbon_g=total_carbon,carbon_per_valid_g=total_carbon/valid if valid else '',mean_response_s_all=sum(responses)/n,p95_response_s_all=sorted(responses)[math.ceil(.95*n)-1],revision_attempts=revisions,revision_successes=revision_success,mean_revisions_per_arrival=revisions/n,capacity_block_rate=capacity_blocks/n,deadline_miss_rate=deadlines/n,deadline_or_capacity_miss_rate=(capacity_blocks+deadlines)/n,router_believed_eligible=believed_pass,believed_eligible_but_invalid=believed_false,misbelief_rate=believed_false/believed_pass if believed_pass else '',synthetic_only=True))
    write_csv(out/'policy_summary.csv',all_summary);write_csv(out/'router_decision_log.csv',all_logs);write_csv(out/'router_feedback_log.csv',all_feedback);write_csv(out/'evaluator_only_audit.csv',all_audit)
    manifest={'schema':'v5-finite-feedback-uncertainty-revision-synthetic-v1','status':'run_complete_pending_independent_check','seed':seed,'synthetic_only':True,'scenarios':len(axes),'policies':list(POLICIES),'inputs_sha256':sha(BASE),'NESO_input_sha256':sha(CI_DATA),'runner_sha256':sha(Path(__file__)),'independent_checker':'simulation/independent_feedback_mechanism_checker.py','independent_checker_sha256':sha(ROOT/'simulation/independent_feedback_mechanism_checker.py'),'result_hashes':{p.name:sha(p) for p in out.glob('*.csv')},'claim_boundary':'mechanism demonstration only; no empirical or deployment inference'}
    (out/'run_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');return manifest

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=OUT_DEFAULT);ap.add_argument('--seed',type=int,default=SEED);a=ap.parse_args();print(json.dumps(run(a.output,a.seed),indent=2))
