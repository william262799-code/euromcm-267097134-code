"""Paired synthetic robustness tests for difficulty, CI forecast errors, load,
demand rebound and task-group effects around the frozen v5 cascade policies.

Only NESO regional forecast covariates are source-backed. Model profiles,
arrival response, capacities, quality, verifier, PUE and network energy remain
explicit scenario assumptions. Latent quality is evaluator-only.
"""
import argparse,bisect,csv,hashlib,json,math,random,statistics
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'simulation/public_ci_joint_v5_scenarios.json'
CI_FILE=ROOT/'data_public/neso_2026_10_09_to_16/regional_forecast.csv'
OUT_DEFAULT=ROOT/'results/v5_robustness_rebound_subgroup'
REGIONS={'London':13,'Wales':17};SLOT=1800;PUE=1.45;GATE=.75
POLICIES=('always_small_local','always_large_local','cascade_joint_carbon','feedback_lcb_joint')
SEEDS=(20261018,20261019,20261020,20261021,20261022)
SCENARIOS=(
 {'name':'baseline','load_multiplier':1,'difficulty_shift':0.,'forecast_sigma':0.,'forecast_bias':0.,'rebound_elasticity':0.,'complex_share':.30},
 {'name':'difficulty_up','load_multiplier':1,'difficulty_shift':.20,'forecast_sigma':0.,'forecast_bias':0.,'rebound_elasticity':0.,'complex_share':.30},
 {'name':'forecast_random_error','load_multiplier':1,'difficulty_shift':0.,'forecast_sigma':.20,'forecast_bias':0.,'rebound_elasticity':0.,'complex_share':.30},
 {'name':'forecast_systematic_bias','load_multiplier':1,'difficulty_shift':0.,'forecast_sigma':0.,'forecast_bias':.20,'rebound_elasticity':0.,'complex_share':.30},
 {'name':'load_growth_1_5x','load_multiplier':1.5,'difficulty_shift':0.,'forecast_sigma':0.,'forecast_bias':0.,'rebound_elasticity':0.,'complex_share':.30},
 {'name':'load_growth_2x','load_multiplier':2,'difficulty_shift':0.,'forecast_sigma':0.,'forecast_bias':0.,'rebound_elasticity':0.,'complex_share':.30},
 {'name':'demand_rebound_eta_025','load_multiplier':1,'difficulty_shift':0.,'forecast_sigma':0.,'forecast_bias':0.,'rebound_elasticity':.25,'complex_share':.30},
 {'name':'demand_rebound','load_multiplier':1,'difficulty_shift':0.,'forecast_sigma':0.,'forecast_bias':0.,'rebound_elasticity':.50,'complex_share':.30},
 {'name':'demand_rebound_eta_100','load_multiplier':1,'difficulty_shift':0.,'forecast_sigma':0.,'forecast_bias':0.,'rebound_elasticity':1.,'complex_share':.30},
 {'name':'complex_share_60pct','load_multiplier':1,'difficulty_shift':0.,'forecast_sigma':0.,'forecast_bias':0.,'rebound_elasticity':0.,'complex_share':.60},
 {'name':'combined_stress','load_multiplier':2,'difficulty_shift':.20,'forecast_sigma':.20,'forecast_bias':.20,'rebound_elasticity':.50,'complex_share':.60},)

def keyed(seed,*parts):
 b='|'.join(map(str,(seed,*parts))).encode();return random.Random(int.from_bytes(hashlib.blake2b(b,digest_size=8).digest(),'big'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def csvout(path,rows):
 with path.open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def wilson(s,n,z=1.645):
 if n<=0:return 0.
 p=s/n;d=1+z*z/n
 return max(0.,(p+z*z/(2*n)-z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)))/d)
def load_ci():
 with CI_FILE.open(newline='',encoding='utf-8') as f:rows=list(csv.DictReader(f))
 out={reg:[float(x['forecast_gco2_per_kwh']) for x in sorted((x for x in rows if int(x['regionid'])==rid and x['region']==reg),key=lambda x:x['from_utc'])] for reg,rid in REGIONS.items()}
 assert all(len(v)==336 for v in out.values());return out
def int_ci(series,t):
 if t<=0:return 0.
 end=len(series)*SLOT
 if t>=end:return sum(series)*SLOT+(t-end)*series[-1]
 idx=min(len(series)-1,int(t//SLOT));return sum(series[:idx])*SLOT+(t-idx*SLOT)*series[idx]
def range_free(book,start,end):
 i=bisect.bisect_right(book,(start+1e-9,math.inf))
 if i and book[i-1][1]>start+1e-9:return False
 return i>=len(book) or book[i][0]>=end-1e-9
def find_start(book,earliest,latest,duration,can_wait):
 step=300 if can_wait else max(1.,latest-earliest+1.)
 n=max(0,int(math.floor((latest-earliest)/step)))
 cand=[earliest+step*k for k in range(n+1)]
 if cand and cand[-1]<latest:cand.append(latest)
 for s in cand:
  if s+duration<=latest+1e-8 and range_free(book,s,s+duration):return s
 return None

def generate_requests(seed,sc,slot_count=336):
 base_n=3*sc['load_multiplier'];reqs=[]
 # All policies use the same seeded pool; rebound adds a policy-specific prefix
 # based on an explicit price-plus-wait demand response, never on latent outcomes.
 for slot in range(slot_count):
  for j in range(12):
   rid=f'{slot:03d}_{j:02d}';r=keyed(seed,'request',rid)
   group='complex' if r.random()<sc['complex_share'] else 'standard'
   raw=r.random();difficulty=min(1.,raw+(.25 if group=='complex' else 0.)+sc['difficulty_shift'])
   home='London' if r.random()<.5 else 'Wales';homeonly=r.random()<.7;delay=r.random()<.6
   arrival=slot*SLOT+r.random()*60
   reqs.append(dict(request_id=rid,slot=slot,arrival=arrival,deadline=arrival+1800,group=group,difficulty=difficulty,home=home,allowed=[home] if homeonly else list(REGIONS),delay=delay))
 return reqs

def rebound_count(policy,base_n,elasticity,seed,scenario,slot):
 if elasticity<=0:return base_n
 # Illustrative demand elasticity: unit generalized cost = action cost +
 # 0.015 cost units per expected service minute. Always-large is reference.
 ref=3.+.015*12.
 idx={'always_small_local':1.+.015*5.,'always_large_local':ref,'cascade_joint_carbon':1.02+.25*3.+.015*8.,'feedback_lcb_joint':1.02+.25*3.+.015*8.}[policy]
 expected=base_n*(1.+elasticity*max(0.,(ref-idx)/ref))
 floor=math.floor(expected);fraction=expected-floor
 # Common random number across policies gives nested, reproducible demand
 # increments while avoiding coarse rounding at only three arrivals per slot.
 return min(base_n+3,floor+int(keyed(seed,scenario,'rebound-rounding',slot).random()<fraction))

def simulate_one(seed,sc,policy,ci,profiles):
 requests=generate_requests(seed,sc);base_n=3*sc['load_multiplier']
 requests=[r for r in requests if int(r['request_id'].split('_')[1])<rebound_count(policy,base_n,sc['rebound_elasticity'],seed,sc['name'],r['slot'])]
 # Router forecast is a noisy view; simulator accounting always uses archived CI.
 pred={reg:[] for reg in REGIONS}
 for reg in REGIONS:
  for slot,actual in enumerate(ci[reg]):
   err=keyed(seed,sc['name'],reg,slot,'forecast-error').gauss(0.,sc['forecast_sigma'])
   bias=(-sc['forecast_bias'] if reg=='London' else sc['forecast_bias'])
   pred[reg].append(max(0.,actual*(1.+bias+err)))
 books={reg:[[] for _ in range(2)] for reg in REGIONS}
 counts={(b,a):[3,1] for b in ('low','high') for a in ('small','large')}
 pending={};rows=[];stages=[];feedback=[];slot_feedback={};
 total={k:0. for k in ('cost','energy','carbon','network_carbon')};valid=served=capacity_miss=deadline_miss=0
 lastslot=-1
 def choose(req,action,ready,check,objective):
  prof=profiles[action];regions=req['allowed'] if objective=='carbon' else [req['home']]
  tr={('London','Wales'):.007,('Wales','London'):.008}.get((req['home'],None),0.)
  cand=[]
  for reg in regions:
   transfer=0. if reg==req['home'] else (.007 if req['home']=='London' else .008)
   earliest=ready+transfer;latest=req['deadline']-prof['service_seconds']-(2. if check else 0.)
   for sid,book in enumerate(books[reg]):
    st=find_start(book,earliest,latest,prof['service_seconds'],req['delay'])
    if st is None:continue
    en=st+prof['service_seconds'];mid=st+prof['service_seconds']/2
    ps=pred[reg][min(335,int(mid//SLOT))]
    predicted_g=prof['it_energy_kwh']*PUE*ps
    if transfer:predicted_g+=.0002*.5*(pred[req['home']][min(335,int((req['arrival']+transfer/2)//SLOT))]+pred[reg][min(335,int((req['arrival']+transfer/2)//SLOT))])
    actual_g=prof['it_energy_kwh']*PUE*(int_ci(ci[reg],en)-int_ci(ci[reg],st))/prof['service_seconds']
    if check:actual_g+=.00002*PUE*ci[reg][min(335,int((en+1)//SLOT))]
    if transfer:actual_g+=.0002*.5*(ci[req['home']][min(335,int((req['arrival']+transfer/2)//SLOT))]+ci[reg][min(335,int((req['arrival']+transfer/2)//SLOT))])
    c=prof['cost_units']+(.02 if check else 0)+(.2 if transfer else 0)
    response=en+(2. if check else 0)-req['arrival']
    key=(predicted_g,c,response,reg,sid,st) if objective=='carbon' else (c,response,predicted_g,reg,sid,st)
    cand.append((key,dict(action=action,region=reg,server=sid,start=st,end=en,transfer_s=transfer,cost=c,energy=prof['it_energy_kwh']+(.00002 if check else 0),predicted_carbon_g=predicted_g,actual_carbon_g=actual_g,check=check)))
  if not cand:return None
  x=min(cand,key=lambda z:z[0])[1];x['oracle_best_actual_carbon_g']=min(z[1]['actual_carbon_g'] for z in cand);x['route_regret_g']=x['actual_carbon_g']-x['oracle_best_actual_carbon_g'];bisect.insort(books[x['region']][x['server']],(x['start'],x['end']))
  return x
 for req in sorted(requests,key=lambda x:(x['arrival'],x['request_id'])):
  if req['slot']!=lastslot:
   for fb in slot_feedback.pop(lastslot,[]) if lastslot>=0 else []:
    z=counts[(fb['bin'],fb['action'])];z[0]+=int(fb['signal']);z[1]+=int(not fb['signal'])
   lastslot=req['slot']
  def estimate(action):
   s,f=counts[(('low' if req['difficulty']<.5 else 'high'),action)];n=s+f
   return max(0.,min(1.,(s/n-.05)/.90)),max(0.,min(1.,(wilson(s,n)-.05)/.90))
  if policy=='always_small_local': first='small'
  elif policy=='always_large_local':first='large'
  elif policy=='cascade_joint_carbon':first='small'
  else:
   mean,lcb=estimate('small')
   explore=keyed(seed,sc['name'],req['request_id'],'explore').random()<.10
   first='small' if (lcb>=.75 or explore) else 'large'
  use_check=policy in ('cascade_joint_carbon','feedback_lcb_joint')
  objective='carbon' if policy.endswith('carbon') or policy.endswith('joint') else 'local'
  action=first;ready=req['arrival'];rowstages=[];served_this=False;delivered=False;reason='';reqcost=reqenergy=reqcarbon=0.;response=0.;accepted_action=''
  maxstage=2 if use_check else 1
  for stage in range(maxstage):
   op=choose(req,action,ready,use_check,objective)
   if op is None:
    reason='capacity_or_deadline';capacity_miss+=1;break
   truthq=keyed(seed,sc['name'],req['request_id'],action,'quality').gauss(max(0.,min(1.,profiles[action]['quality_intercept']-profiles[action]['quality_difficulty_slope']*req['difficulty'])),profiles[action]['quality_noise_sd'])
   truthq=max(0.,min(1.,truthq));truth=truthq>=GATE
   vp=None
   if use_check:
    fa=keyed(seed,sc['name'],req['request_id'],action,'verifier').random();vp=fa<(.95 if truth else .05)
   slot=min(335,int((op['start']+profiles[action]['service_seconds']/2)//SLOT))
   actual_g=profiles[action]['it_energy_kwh']*PUE*(int_ci(ci[op['region']],op['end'])-int_ci(ci[op['region']],op['start']))/profiles[action]['service_seconds']
   network_g=0.
   if op['transfer_s']:
    net_slot=min(335,int((req['arrival']+op['transfer_s']/2)//SLOT));network_g=.0002*.5*(ci[req['home']][net_slot]+ci[op['region']][net_slot])
   if use_check:actual_g+=.00002*PUE*ci[op['region']][min(335,int((op['end']+1)//SLOT))]
   network_energy=.0002 if op['transfer_s'] else 0.
   reqcost+=op['cost'];reqenergy+=op['energy']+network_energy;reqcarbon+=actual_g+network_g
   response=op['end']+(2. if use_check else 0.)-req['arrival'];accepted=(vp is None or vp)
   stage_row=dict(request_id=req['request_id'],stage=stage+1,action=action,region=op['region'],server=op['server'],start=op['start'],end=op['end'],quality_truth=truthq,quality_pass=truth,verifier_pass=vp,cost=op['cost'],energy=op['energy']+network_energy,actual_carbon_g=actual_g+network_g,predicted_carbon_g=op['predicted_carbon_g'],oracle_best_actual_carbon_g=op['oracle_best_actual_carbon_g'],route_regret_g=op['route_regret_g'])
   rowstages.append(stage_row);stages.append(dict(scenario=sc['name'],seed=seed,policy=policy,**stage_row))
   if use_check:
    fb=dict(bin='low' if req['difficulty']<.5 else 'high',action=action,signal=vp)
    slot_feedback.setdefault(req['slot'],[]).append(fb)
    feedback.append(dict(scenario=sc['name'],seed=seed,policy=policy,request_id=req['request_id'],slot=req['slot'],stage=stage+1,action=action,verifier_pass=vp,feedback_available_after_stage=True,model_update_after_slot=req['slot']+1 if policy=='feedback_lcb_joint' else 'never'))
   if accepted:
    served_this=True;delivered=True;accepted_action=action;break
   if stage==0:
    action='large';ready=op['end']+2.;continue
   reason='verifier_rejected';break
  if served_this:served+=1
  isvalid=bool(delivered and rowstages[-1]['quality_pass'] and response<=req['deadline']-req['arrival']+1e-8)
  valid+=int(isvalid)
  if not delivered and reason=='capacity_or_deadline':deadline_miss+=1
  total['cost']+=reqcost;total['energy']+=reqenergy;total['carbon']+=reqcarbon
  rows.append(dict(scenario=sc['name'],seed=seed,policy=policy,request_id=req['request_id'],slot=req['slot'],arrival_s=req['arrival'],deadline_s=req['deadline'],group=req['group'],difficulty=req['difficulty'],home_region=req['home'],served=served_this,valid=isvalid,selected_action=accepted_action,stages=len(rowstages),response_s=response if rowstages else '',cost=reqcost,energy_kWh=reqenergy,carbon_g=reqcarbon,reason=reason,synthetic_only=True))
 # Flush final batch feedback only after no later decisions remain; it cannot affect this run.
 n=len(rows);groups={g:[x for x in rows if x['group']==g] for g in ('standard','complex')}
 policy_stages=[z for z in stages if z['scenario']==sc['name'] and z['seed']==seed and z['policy']==policy]
 summary=dict(scenario=sc['name'],seed=seed,policy=policy,N_arrivals=n,N_served=sum(x['served'] for x in rows),N_valid=sum(x['valid'] for x in rows),valid_rate=sum(x['valid'] for x in rows)/n if n else 0.,served_rate=sum(x['served'] for x in rows)/n if n else 0.,system_cost_units=total['cost'],cost_per_valid=total['cost']/valid if valid else '',mean_response_s=sum(float(x['response_s'] or 0) for x in rows if x['served'])/served if served else 0.,mean_route_regret_g=sum(float(z['route_regret_g']) for z in policy_stages)/len(policy_stages) if policy_stages else 0.,system_energy_kWh=total['energy'],system_carbon_g=total['carbon'],carbon_per_arrival_g=total['carbon']/n if n else 0.,carbon_per_valid_g=total['carbon']/valid if valid else '',deadline_or_capacity_miss_rate=deadline_miss/n if n else 0.,revision_rate=sum(max(0,x['stages']-1) for x in rows)/n if n else 0.,synthetic_only=True)
 group_rows=[]
 for g,xs in groups.items():
  if not xs:continue
  nv=sum(z['valid'] for z in xs);sv=sum(z['served'] for z in xs);group_rows.append(dict(scenario=sc['name'],seed=seed,policy=policy,group=g,N_arrivals=len(xs),valid_rate=nv/len(xs),served_rate=sv/len(xs),mean_response_s=sum(float(z['response_s'] or 0) for z in xs if z['served'])/sv if sv else 0.,cost_per_valid=sum(z['cost'] for z in xs)/nv if nv else '',deadline_or_capacity_miss_rate=sum(z['reason']=='capacity_or_deadline' for z in xs)/len(xs)))
 return summary,rows,stages,feedback,group_rows

def main(out):
 out=Path(out);out.mkdir(parents=True,exist_ok=True);ci=load_ci();cfg=json.loads(BASE.read_text());profiles=cfg['actions']
 config={'claim':'synthetic paired robustness experiment; not deployment evidence','seeds':list(SEEDS),'scenario_definitions':list(SCENARIOS),'policies':list(POLICIES),'shared_request_pool':'same seed/scenario request IDs and potential quality draws across policies; rebound adds policy-specific, nested requests with common seeded fractional rounding per time slot','difficulty':'standard requests draw U(0,1); complex requests add 0.25; difficulty_up adds 0.20 to all, clipped at 1','quality_gate':GATE,'verifier_FA_FR':{'FA':.05,'FR':.05},'feedback_prior':'Beta(3,1) per difficulty bin and action; router observes only verifier pass/fail; LCB uses 90% Wilson score lower bound, corrected for fixed synthetic FA/FR; 10% seeded small-action exploration','forecast_error':'router forecast = max(0, actual archived regional CI × (1 + regional bias + Normal(0,sigma))); systematic stress underpredicts London by 20% and overpredicts Wales by 20%; actual carbon accounting uses archived CI only','route_regret':'selected stage carbon minus minimum actual carbon among action-region-time-server candidates feasible at that decision under residency, deadline and current capacity; evaluator-only diagnostic unavailable to router','carbon_objective':'carbon-first tuple among allowed region/start/server candidates; fixed baselines use home region and earliest feasible start','capacity_deadline':'two servers per region; exact non-overlap intervals; 1800 s request deadline; joint policies may wait in 300 s increments only when delay is allowed','rebound_formula':'expected arrivals N_base×[1+eta×max(0,(g_ref-g_policy)/g_ref)], g=nominal action cost + 0.015×expected service minutes; g_ref is always-large; fractional requests are stochastically rounded per slot with common random numbers across policies','subgroups':'standard vs complex; complex share is 0.30 normally and 0.60 in subgroup/combined stress; both use the same Q>=0.75 outcome gate','profiles_from':'simulation/public_ci_joint_v5_scenarios.json; synthetic assumptions, not measured model/hardware values','pue':PUE,'remote_network_energy_kwh':.0002,'limitations':['Five seeds only; all numeric model, verifier, cost, service, capacity, PUE, and demand response profiles are synthetic.','Regional CI is a sourced forecast covariate, not site or marginal emissions; forecast vintage is not point-in-time verified.','Queue capacity uses exact server intervals, but candidate times are searched on a 300-second grid.','No real user elasticity, subgroup labels, quality scores, or data-center measurements.']}
 (out/'scenario_config.json').write_text(json.dumps(config,indent=2)+'\n')
 sums=[];allreq=[];allstages=[];allfeedback=[];allgroups=[]
 for sc in SCENARIOS:
  for seed in SEEDS:
   for pol in POLICIES:
    s,r,st,fb,g=simulate_one(seed,sc,pol,ci,profiles);sums.append(s);allreq.extend(dict(scenario=s['scenario'],seed=seed,policy=pol,**{k:v for k,v in x.items() if k not in ('scenario','seed','policy')}) for x in r);allstages.extend(dict(scenario=s['scenario'],seed=seed,policy=pol,**{k:v for k,v in x.items() if k not in ('scenario','seed','policy')}) for x in st);allfeedback.extend(fb);allgroups.extend(g)
 seed_groups={}
 for x in sums:seed_groups.setdefault((x['scenario'],x['policy']),[]).append(x)
 aggregate=[]
 for (scenario,policy),xs in sorted(seed_groups.items()):
  row={'scenario':scenario,'policy':policy,'seed_count':len(xs)}
  for field in ('N_arrivals','valid_rate','served_rate','system_cost_units','cost_per_valid','mean_response_s','mean_route_regret_g','system_energy_kWh','system_carbon_g','carbon_per_arrival_g','carbon_per_valid_g','deadline_or_capacity_miss_rate','revision_rate'):
   vals=[float(x[field]) for x in xs if x[field]!=''];m=statistics.mean(vals);se=statistics.stdev(vals)/math.sqrt(len(vals)) if len(vals)>1 else 0.
   # Two-sided 95% Student-t interval, df=4 (five independent run seeds).
   row[field+'_mean']=m;row[field+'_ci95_low']=m-2.776*se;row[field+'_ci95_high']=m+2.776*se
  aggregate.append(row)
 csvout(out/'seed_policy_summary.csv',sums);csvout(out/'factor_summary_mean_ci.csv',aggregate);csvout(out/'request_outcomes_evaluator_only.csv',allreq);csvout(out/'stage_ledger_evaluator_only.csv',allstages);csvout(out/'router_feedback_log.csv',allfeedback);csvout(out/'subgroup_summary_by_seed.csv',allgroups)
 manifest={'schema':'v5-robustness-rebound-subgroup-v1','status':'run_complete_pending_independent_check','synthetic_only':True,'seed_count':len(SEEDS),'scenario_count':len(SCENARIOS),'policy_count':len(POLICIES),'runner_sha256':sha(Path(__file__)),'checker':'simulation/independent_v5_robustness_checker.py','checker_sha256':sha(ROOT/'simulation/independent_v5_robustness_checker.py'),'base_profile_sha256':sha(BASE),'NESO_data_sha256':sha(CI_FILE),'result_hashes':{p.name:sha(p) for p in out.glob('*.csv')},'claim_boundary':'conditional synthetic robustness assessment only'}
 (out/'run_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');return manifest

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=OUT_DEFAULT);a=ap.parse_args();print(json.dumps(main(a.output),indent=2))
