"""Conditional synthetic small->verifier->optional-large cascade on public NESO CI.
All operation profiles, quality and verifier parameters, capacity and arrivals are explicit synthetic scenarios.
"""
import argparse,bisect,csv,hashlib,json,math,random
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'simulation/public_ci_joint_v5_scenarios.json'
DATA=ROOT/'data_public/neso_2026_10_09_to_16/regional_forecast.csv'
MAN=DATA.parent/'manifest.json'
RTT=ROOT/'data_public/azure_rtt_2026-07-30/uk_south_uk_west_p50.json'
CHECKER=ROOT/'simulation/independent_cascade_joint_v5_checker.py'
REGIONS=('london_uk_south','cardiff_uk_west')
POLICIES=('always_small_local','always_large_local','quality_gated_local_cost','quality_gated_joint_carbon','cascade_local','cascade_joint_carbon')
SLOT=1800

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def keyed(seed,*x):return random.Random(int.from_bytes(hashlib.blake2b('|'.join(map(str,(seed,*x))).encode(),digest_size=8).digest(),'big'))
def window_intervals(intervals,earliest,latest,duration,max_prior_duration):
 """Use start-sorted bookings to retrieve only intervals that can overlap."""
 lo=bisect.bisect_left(intervals,(earliest-max_prior_duration-1e-9,-math.inf))
 hi=bisect.bisect_left(intervals,(latest+duration-1e-9,-math.inf))
 return [(a,b) for a,b in intervals[lo:hi] if b>earliest+1e-9]
def interval_free(intervals,start,end):
 """Check a proposed interval against sorted, non-overlapping bookings in O(log n)."""
 i=bisect.bisect_right(intervals,(start+1e-9,math.inf))
 if i and intervals[i-1][1]>start+1e-9:return False
 if i<len(intervals) and intervals[i][0]<end-1e-9:return False
 return True
def earliest_feasible_start(earliest,latest,delay,intervals,duration,max_prior_duration):
 """For cost-first tuples, find only the earliest feasible start in O(n)."""
 if not delay:return earliest if earliest<=latest and interval_free(intervals,earliest,earliest+duration) else None
 start=earliest
 for a,b in window_intervals(intervals,earliest,latest,duration,max_prior_duration):
  if b<=start+1e-9:continue
  if start+duration<=a+1e-9:break
  start=b
  if start>latest+1e-9:return None
 return start if start<=latest+1e-9 and interval_free(intervals,start,start+duration) else None
def candidate_starts(earliest,latest,delay,intervals,duration,check_s,transfer_s,max_prior_duration):
 """Finite exact candidate set for interval feasibility and piecewise lexicographic costs.

 Includes service start/end CI breakpoints, checker midpoint CI breakpoints,
 network midpoint CI breakpoints, left limits at discontinuities, and both
 sides of occupied intervals (including a task ending at a future booking).
 """
 if not delay:return [earliest]
 points={earliest,latest}
 # Historical bookings wholly before this request and distant future bookings
 # cannot change feasibility inside [earliest, latest]. Excluding them keeps
 # candidate generation linear in the local horizon rather than all history.
 relevant=window_intervals(intervals,earliest,latest,duration,max_prior_duration)
 for a,b in relevant:
  points.update((b,a-duration))
 lo=max(0,int(math.floor((earliest-max(duration+check_s,transfer_s,0))/SLOT))-1)
 hi=int(math.ceil((latest+max(duration+check_s,transfer_s,0))/SLOT))+1
 discontinuities=[]
 for k in range(lo,hi+1):
  edge=k*SLOT
  discontinuities.extend((edge,edge-duration))
  if check_s:discontinuities.append(edge-duration-check_s/2.)
  if transfer_s:discontinuities.append(edge+transfer_s/2.)
 for x in discontinuities:
  if earliest-1e-9<=x<=latest+1e-9:
   points.add(x)
   left=math.nextafter(x,-math.inf)
   if earliest<=left<=latest:points.add(left)
 return sorted(x for x in points if earliest-1e-9<=x<=latest+1e-9)
def csvout(p,rows):
 with Path(p).open('w',newline='',encoding='utf8') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def ci_read():
 assert sha(DATA)==json.loads(MAN.read_text())['processed_sha256']
 with DATA.open(newline='') as f: data=list(csv.DictReader(f))
 seq={};ts=None
 for reg,rid,label in ((REGIONS[0],'13','London'),(REGIONS[1],'17','Wales')):
  a=sorted((x for x in data if x['regionid']==rid and x['region']==label),key=lambda x:x['from_utc']);assert len(a)==336
  seq[reg]=[float(x['forecast_gco2_per_kwh']) for x in a]
  if ts is None:ts=[x['from_utc'] for x in a]
  else:assert ts==[x['from_utc'] for x in a]
 return seq,ts

def main(out,seed):
 cfg=json.loads(BASE.read_text());ci,times=ci_read();out=Path(out);out.mkdir(parents=True,exist_ok=True)
 # Prefix integrals make service-carbon evaluation O(1) per candidate start,
 # while preserving the half-hour CI step function and the final-slot clamp.
 ci_integral={}
 for region,series in ci.items():
  pref=[0.]
  for value in series:pref.append(pref[-1]+float(value)*SLOT)
  ci_integral[region]=(pref,series)
 def integrated_ci(region,t):
  pref,series=ci_integral[region]
  end=len(series)*SLOT
  if t>=end:return pref[-1]+(t-end)*series[-1]
  if t<=0:return 0.
  slot=min(len(series)-1,int(t//SLOT))
  return pref[slot]+(t-slot*SLOT)*series[slot]
 # Full Cartesian sensitivity grid is intentionally modest and every point is a design assumption.
 axes=[]
 for load in (3,6):
  for qshift in (-.04,0,.04):
   for fa,fr in ((.05,.05),(.20,.05),(.02,.10)):
    for largecost in (1.,1.5):
     axes.append(dict(load_per_slot=load,quality_shift=qshift,FA=fa,FR=fr,large_cost_multiplier=largecost,quality_gate=.75))
 assumptions={'claim':'conditional synthetic cascade experiment; NESO CI and published regional P50 RTT are source-backed covariates only',
  'all_other_inputs':'synthetic scenario design; not empirical model/hardware/service/verifier calibration',
  'axes':{'load_per_slot':[3,6],'quality_shift':[-.04,0,.04],'FA_FR':[[.05,.05],[.20,.05],[.02,.10]],'large_cost_multiplier':[1.,1.5],'quality_gate':.75},
  'profiles':{'small':{'q_intercept':.90,'difficulty_slope':.30,'noise_sd':.12,'service_seconds':300,'IT_kWh':.003,'cost_units':1.0},'large':{'q_intercept':.98,'difficulty_slope':.15,'noise_sd':.10,'service_seconds':720,'IT_kWh':.009,'cost_units':3.0},'check':{'seconds':2.,'cost_units':.02,'IT_kWh':.00002}},
  'capacity_servers_per_region':2,'PUE':1.45,'network_energy_kWh_per_remote_stage':.0002,'network_cost_units_per_remote_stage':.2,
  'network_RTT_ms':{'London_to_Cardiff':7,'Cardiff_to_London':8},'network_CI_split_source_target':[.5,.5],
  'deadline_s_after_arrival':1800,'residency_home_only_probability':.7,'delay_allowed_probability':.6,
  'checker_semantics':'T=quality>=gate; P(pass|T=1)=1-FR, P(pass|T=0)=FA; pre-generated shared request×action outcomes across policies',
  'cascade':'run small, execute verifier; if fail, attempt at most one large stage only if server interval, deadline and residency permit; verify large; fail means no delivery',
  'latency':'response includes per-stage RTT + service duration + 2s checker each executed stage; network application overhead unknown and omitted',
  'energy_carbon':'service/check IT energy multiplied by PUE and regional CI at operation midpoint; network kWh each remote stage split 50/50 source/target CI at RTT midpoint, no PUE',
  'online_scope':'uses paired historical CI intervals across archived window for operation-midpoint accounting; not real-time dispatch forecasting'}
 (out/'scenario_config.json').write_text(json.dumps(assumptions,indent=2)+'\n')
 requests=[];audit=[]
 # arrival stream by load; deterministic for seed. Home and difficulty independent draws.
 for s in range(336):
  for j in range(6):
   rr=keyed(seed,'req',s,j);arrival=s*SLOT+rr.uniform(0,60);home=REGIONS[0] if rr.random()<.5 else REGIONS[1]
   homeonly=rr.random()<.7;delay=rr.random()<.6;d=rr.random();rid=f'r{s:03d}_{j}'
   requests.append(dict(request_id=rid,arrival_s=arrival,deadline_s=arrival+1800,arrival_slot=s,home=home,allowed='|'.join([home] if homeonly else REGIONS),delay=delay,difficulty=d))
 assign=[];summaries=[];common=[];audit=[];stage_rows=[]
 def rtt(home,region):return 0 if home==region else (.007 if home==REGIONS[0] else .008)
 def service_g(region,start,dur,energy):
  return energy/dur*1.45*(integrated_ci(region,start+dur)-integrated_ci(region,start))
 def check_g(region,t):
  # The 2 s control-plane check is costed at its interval midpoint.
  k=min(335,int((t+1.)//SLOT));return .00002*1.45*ci[region][k]
 def choose(r,action,policy,book,scenario,stage,largecost,with_check=True):
  prof=cfg['actions'][action];regions=[r['home']] if policy in ('always_small_local','always_large_local','quality_gated_local_cost','cascade_local') else r['allowed'].split('|')
  check_s=2. if with_check else 0.
  options=[]
  for region in regions:
   if region not in r['allowed'].split('|'):continue
   tr=rtt(r['home'],region);earliest=r['arrival_s']+tr if stage==1 else stage['ready_s']+tr
   latest=r['deadline_s']-prof['service_seconds']-check_s
   if latest<earliest:continue
   servers=book[region]
   for sid,intervals in enumerate(servers):
    max_prior_duration=max(float(p['service_seconds']) for p in cfg['actions'].values())
    if policy in ('cascade_joint_carbon','quality_gated_joint_carbon'):
     starts=candidate_starts(earliest,latest,r['delay'],intervals,prof['service_seconds'],check_s,tr,max_prior_duration)
    else:
     first=earliest_feasible_start(earliest,latest,r['delay'],intervals,prof['service_seconds'],max_prior_duration)
     starts=[] if first is None else [first]
    for st in sorted(starts):
     en=st+prof['service_seconds']
     if en+check_s>r['deadline_s']+1e-8 or not interval_free(intervals,st,en):continue
     energy=prof['it_energy_kwh'];netk=.0002 if tr else 0;mid=(max(r['arrival_s'],st-tr)+st)/2;ix=min(335,int(mid//SLOT));ng=netk*.5*(ci[r['home']][ix]+ci[region][ix])
     sg=service_g(region,st,prof['service_seconds'],energy);cg=check_g(region,en) if with_check else 0.
     cost=prof['cost_units']*(largecost if action=='large' else 1)+(0.02 if with_check else 0)+(.2 if tr else 0)
     totalg=sg+cg+ng
     resp=en+check_s-r['arrival_s']
     key=(totalg,cost,resp,region,sid,st) if policy in ('cascade_joint_carbon','quality_gated_joint_carbon') else (cost,resp,totalg,region,sid,st)
     options.append((key,dict(action=action,region=region,server=sid,start=st,end=en,transfer_s=tr,service_g=sg,checker_g=cg,network_g=ng,total_g=totalg,IT_kWh=energy+(.00002 if with_check else 0),network_kWh=netk,cost=cost,response=resp,check_time=check_s,with_check=with_check)))
  return min(options,key=lambda x:x[0])[1] if options else None
 for ai,sc in enumerate(axes):
  if ai%6==0: print(f"scenario {ai+1}/{len(axes)}",flush=True)
  # scale arrival count by repeating deterministic canonical requests; first load IDs are paired across policies.
  reqs=[]
  for r in requests:
   if int(r['request_id'].split('_')[1]) < sc['load_per_slot']:reqs.append(r)
  # Scenario-specific quality shift; shared keyed noise keeps strategies paired.
  qmap={}
  for r in reqs:
   for action in ('small','large'):
    prof=cfg['actions'][action];qh=max(0,min(1,prof['quality_intercept']+sc['quality_shift']-prof['quality_difficulty_slope']*r['difficulty']))
    quality=max(0,min(1,keyed(seed,r['request_id'],action,'q').gauss(qh,prof['quality_noise_sd'])))
    qmap[(r['request_id'],action)]=quality
    audit.append(dict(scenario_id=f's{ai:02d}',request_id=r['request_id'],action=action,qhat=qh,actual_quality=quality,synthetic_latent_only=True))
  for policy in POLICIES:
   book={reg:[[] for _ in range(2)] for reg in REGIONS};rows=[]
   for r in sorted(reqs,key=lambda z:(z['arrival_s'],z['request_id'])):
    stages=[];accepted=False;terminal='';current='small' if policy in ('always_small_local','quality_gated_local_cost','quality_gated_joint_carbon','cascade_local','cascade_joint_carbon') else 'large'
    is_cascade=policy.startswith('cascade');maxstages=2 if is_cascade else 1;stage_no=0;ready=r['arrival_s'];delivered_action='';total={k:0. for k in ('cost','carbon','compute_g','network_g','IT_kWh','network_kWh','response')};false_accept=False;false_reject=False
    if not is_cascade:
     candidate_options=[]
     choices=('small','large') if policy.startswith('quality_gated') else (current,)
     for action in choices:
      profile=cfg['actions'][action];qpoint=max(0,min(1,profile['quality_intercept']+sc['quality_shift']-profile['quality_difficulty_slope']*r['difficulty']))
      if policy.startswith('quality_gated') and qpoint+1e-12<sc['quality_gate']:continue
      opt=choose(r,action,policy,book,sc,1,sc['large_cost_multiplier'],False)
      if opt is not None:candidate_options.append(opt)
     if candidate_options:
      candidate=min(candidate_options,key=lambda z: ((z['total_g'],z['cost'],z['response'],z['action'],z['region'],z['server'],z['start']) if policy=='quality_gated_joint_carbon' else (z['cost'],z['response'],z['total_g'],z['action'],z['server'],z['start'])))
      bisect.insort(book[candidate['region']][candidate['server']],(candidate['start'],candidate['end']))
      stages.append(candidate);stage_rows.append(dict(scenario_id=f's{ai:02d}',policy=policy,request_id=r['request_id'],stage=1,verifier_pass='',quality_truth='',synthetic_conditional=True,**candidate))
      delivered_action=candidate['action'];accepted=True;terminal='delivered_without_verifier'
      for k,v in [('cost',candidate['cost']),('carbon',candidate['service_g']+candidate['checker_g']+candidate['network_g']),('compute_g',candidate['service_g']+candidate['checker_g']),('network_g',candidate['network_g']),('IT_kWh',candidate['IT_kWh']),('network_kWh',candidate['network_kWh'])]:total[k]+=v
      total['response']=candidate['response']
     else:terminal='quality_or_capacity_infeasible'
    while is_cascade and stage_no<maxstages:
     stage_no+=1;action=current
     candidate=choose(r,action,policy,book,sc,{'ready_s':ready} if stage_no>1 else 1,sc['large_cost_multiplier'])
     if candidate is None:
      terminal='initial_infeasible' if stage_no==1 else 'upgrade_infeasible';break
     # Shared verifier coin keyed to scenario FA/FR and action, guaranteed same for comparator policies.
     quality=qmap[(r['request_id'],action)];truth=quality>=sc['quality_gate'];p_pass=(1-sc['FR']) if truth else sc['FA']
     passv=keyed(seed,'v',sc['FA'],sc['FR'],r['request_id'],action).random()<p_pass
     candidate.update({'stage':stage_no,'verifier_pass':passv,'quality_truth':truth})
     # reserve and count resource; append service occupancy only once actually executed
     bisect.insort(book[candidate['region']][candidate['server']],(candidate['start'],candidate['end']))
     for k,v in [('cost',candidate['cost']),('carbon',candidate['service_g']+candidate['checker_g']+candidate['network_g']),('compute_g',candidate['service_g']+candidate['checker_g']),('network_g',candidate['network_g']),('IT_kWh',candidate['IT_kWh']),('network_kWh',candidate['network_kWh'])]:total[k]+=v
     total['response']=candidate['response'] if stage_no==1 else candidate['end']+2-r['arrival_s']
     stages.append(candidate);stage_rows.append(dict(scenario_id=f's{ai:02d}',policy=policy,request_id=r['request_id'],**candidate,synthetic_conditional=True));false_accept |= passv and not truth;false_reject |= (not passv) and truth
     if passv:
      accepted=True;delivered_action=action;terminal='delivered';break
     if stage_no==1 and maxstages==2:
      # retry starts only after first check; action is escalated once.
      ready=candidate['end']+2;current='large';continue
     terminal='verifier_rejected';break
    served=accepted;last=stages[-1] if stages else None;valid=bool(served and qmap[(r['request_id'],delivered_action)]>=sc['quality_gate'] and last['end']+last['check_time']<=r['deadline_s']+1e-8)
    if last: total['response']=last['end']+last['check_time']-r['arrival_s']
    row=dict(scenario_id=f's{ai:02d}',policy=policy,request_id=r['request_id'],arrival_s=r['arrival_s'],deadline_s=r['deadline_s'],home_region=r['home'],allowed_regions=r['allowed'],delay_allowed=r['delay'],difficulty=r['difficulty'],load_per_slot=sc['load_per_slot'],quality_shift_design=sc['quality_shift'],large_cost_multiplier=sc['large_cost_multiplier'],FA=sc['FA'],FR=sc['FR'],quality_gate=sc['quality_gate'],served=served,valid=valid,terminal_status=terminal,selected_action=delivered_action,attempted_stages=len(stages),upgrade_attempted=len(stages)>1,response_s=total['response'] if stages else '',total_cost_units=total['cost'],total_carbon_g=total['carbon'],compute_carbon_g=total['compute_g'],network_carbon_g=total['network_g'],IT_energy_kWh=total['IT_kWh'],network_energy_kWh=total['network_kWh'],false_accept=false_accept,false_reject=false_reject,synthetic_conditional=True)
    rows.append(row);assign.append(row)
   n=len(rows);sv=[x for x in rows if x['served']];va=[x for x in rows if x['valid']]
   executed_checks=[x for x in stage_rows if x['scenario_id']==f's{ai:02d}' and x['policy']==policy and x['with_check']]
   u_calls=sum(x['quality_truth'] is False for x in executed_checks);q_calls=sum(x['quality_truth'] is True for x in executed_checks)
   fa_events=sum(x['quality_truth'] is False and x['verifier_pass'] is True for x in executed_checks);fr_events=sum(x['quality_truth'] is True and x['verifier_pass'] is False for x in executed_checks)
   summaries.append(dict(scenario_id=f's{ai:02d}',load_per_slot=sc['load_per_slot'],quality_shift_design=sc['quality_shift'],FA=sc['FA'],FR=sc['FR'],large_cost_multiplier=sc['large_cost_multiplier'],policy=policy,N_arrivals=n,N_served=len(sv),N_unserved=n-len(sv),N_valid=len(va),valid_rate_arrivals=len(va)/n,valid_rate_served=len(va)/len(sv) if sv else '',upgrade_attempts=sum(x['upgrade_attempted'] for x in rows),verifier_calls=len(executed_checks),unqualified_verifier_calls=u_calls,false_accept_events=fa_events,empirical_FA_rate=fa_events/u_calls if u_calls else '',qualified_verifier_calls=q_calls,false_reject_events=fr_events,empirical_FR_rate=fr_events/q_calls if q_calls else '',system_cost_units=sum(x['total_cost_units'] for x in rows),cost_per_arrival=sum(x['total_cost_units'] for x in rows)/n,cost_per_valid=sum(x['total_cost_units'] for x in rows)/len(va) if va else '',system_carbon_g=sum(x['total_carbon_g'] for x in rows),carbon_g_per_arrival=sum(x['total_carbon_g'] for x in rows)/n,carbon_g_per_valid=sum(x['total_carbon_g'] for x in rows)/len(va) if va else '',system_IT_energy_kWh=sum(x['IT_energy_kWh'] for x in rows),system_network_energy_kWh=sum(x['network_energy_kWh'] for x in rows),mean_response_s_served=sum(float(x['response_s']) for x in sv)/len(sv) if sv else '',p95_response_s_served=sorted(float(x['response_s']) for x in sv)[math.ceil(.95*len(sv))-1] if sv else '',quality_gate=.75,synthetic_conditional=True))
 # paired common-served all strategies per scenario
 for i in range(len(axes)):
  groups={p:{x['request_id']:x for x in assign if x['scenario_id']==f's{i:02d}' and x['policy']==p} for p in POLICIES}
  ids=set.intersection(*(set(k for k,v in x.items() if v['served']) for x in groups.values()))
  for p in POLICIES:
   c=[groups[p][rid] for rid in sorted(ids)]
   common.append(dict(scenario_id=f's{i:02d}',policy=p,N_common_served=len(ids),common_cost_per_request=sum(x['total_cost_units'] for x in c)/len(c) if c else '',common_carbon_per_request=sum(x['total_carbon_g'] for x in c)/len(c) if c else '',common_mean_response_s=sum(float(x['response_s']) for x in c)/len(c) if c else '',common_valid_rate=sum(x['valid'] for x in c)/len(c) if c else '',synthetic_conditional=True))
 csvout(out/'cascade_assignments.csv',assign);csvout(out/'cascade_stage_ledger.csv',stage_rows);csvout(out/'cascade_audit_outcomes.csv',audit);csvout(out/'cascade_summary.csv',summaries);csvout(out/'cascade_common_served.csv',common)
 manifest={'schema':'conditional-synthetic-cascade-v5-v1','status':'run_complete_pending_independent_checker','seed':seed,'synthetic_only':True,'scenario_count':len(axes),'policy_names':list(POLICIES),'request_rows_by_load_scenario':{'3':1008,'6':2016},'scenario_config_sha256':sha(out/'scenario_config.json'),'NESO_sha256':sha(DATA),'Azure_RTT_sha256':sha(RTT),'runner_sha256':sha(Path(__file__)),'independent_checker_file':'simulation/independent_cascade_joint_v5_checker.py','independent_checker_sha256':sha(CHECKER),'independent_validation_report_file':'independent_validation_report.json','result_hashes':{p.name:sha(p) for p in out.glob('*.csv')},'limitations':['No empirical calibration of quality, FA/FR, service, energy, cost, or capacity.','Single configurable seed.','Archived CI used for ex-post operation carbon; not a live online forecast.','Fixed 2 servers per region, PUE 1.45 and 7/8ms RTT scenario.','Verifier overhead synthetic; no control-plane capacity constraint.','Direct baselines omit verifier; cascade strategies include one verifier per executed stage.']}
 (out/'run_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');return manifest
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'results/cascade_joint_v5_conditional');ap.add_argument('--seed',type=int,default=20261017);a=ap.parse_args();print(json.dumps(main(a.output,a.seed),indent=2))
