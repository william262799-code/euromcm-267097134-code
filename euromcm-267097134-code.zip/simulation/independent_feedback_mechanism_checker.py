"""Independent structural and summary checker; imports no simulator code."""
import argparse,csv,hashlib,json,math,random
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(p):
 with p.open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def need(x,m):
 if not x:raise AssertionError(m)
def wilson_lower(s,n,z=1.645):
 p=s/n;d=1+z*z/n
 return max(0.,(p+z*z/(2*n)-z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)))/d)
def keyed(seed,*parts):
 raw='|'.join(map(str,(seed,*parts))).encode()
 return random.Random(int.from_bytes(hashlib.blake2b(raw,digest_size=8).digest(),'big'))
def check(out):
 out=Path(out);man=json.loads((out/'run_manifest.json').read_text())
 need(man['synthetic_only'] is True,'missing synthetic-only boundary')
 need(man['runner_sha256']==sha(ROOT/'simulation/feedback_uncertainty_revision_experiment.py'),'runner hash mismatch')
 need(man['independent_checker_sha256']==sha(Path(__file__)),'checker hash mismatch')
 need(man['inputs_sha256']==sha(ROOT/'simulation/public_ci_joint_v5_scenarios.json'),'frozen input hash mismatch')
 need(man['NESO_input_sha256']==sha(ROOT/'data_public/neso_2026_10_09_to_16/regional_forecast.csv'),'NESO input hash mismatch')
 for name,digest in man['result_hashes'].items():need(sha(out/name)==digest,f'result hash mismatch: {name}')
 logs=rows(out/'router_decision_log.csv');audit=rows(out/'evaluator_only_audit.csv');summ=rows(out/'policy_summary.csv');feedback=rows(out/'router_feedback_log.csv')
 forbidden={'latent_quality','quality_pass','quality_truth','actual_quality','true_difficulty'}
 need(not (set(logs[0])&forbidden),'latent evaluator field leaked into router log')
 need(not (set(feedback[0])&forbidden),'latent evaluator field leaked into router feedback log')
 for x in logs:
  slot=int(x['slot']);need(int(x['router_feedback_available_through_slot'])<slot,'router saw current/future batch feedback')
  need(int(x['feedback_updated_after_slot'])==slot,'feedback timestamp mismatch')
  need(int(x['stages'])>=0,'negative stage count')
 groups={}
 for x in audit:groups.setdefault((x['scenario_id'],x['policy'],x['request_id']),[]).append(x)
 for k,v in groups.items():
  v.sort(key=lambda z:int(z['stage']));need([int(x['stage']) for x in v]==list(range(1,len(v)+1)),'stage numbering gap')
  need(len(v)<=3,'revision cap exceeded')
  for x in v:need(x['synthetic_latent_evaluator_only']=='True','audit boundary marker missing')
 audit_by_key={(x['scenario_id'],x['policy'],x['request_id'],x['stage']):x for x in audit}
 bylog={(x['scenario_id'],x['policy'],x['request_id']):x for x in logs}
 feedback_by_key={(x['scenario_id'],x['policy'],x['request_id'],x['stage']):x for x in feedback}
 need(len(feedback)==len(audit),'feedback/audit stage counts differ')
 for f in feedback:
  key=(f['scenario_id'],f['policy'],f['request_id'],f['stage'])
  need(key in audit_by_key,'feedback has no executed stage')
  need(f['action']==audit_by_key[key]['action'],'feedback action disagrees with stage ledger')
  need(f['verifier_pass']==audit_by_key[key]['verifier_pass'],'visible verifier result disagrees with stage outcome')
  need(f['feedback_available_after_stage']=='True','stage feedback was not exposed to router')
  need(f['model_update_available_after_slot'] in ('never',str(int(f['slot'])+1)),'history update timing invalid')
 # Replay the router's online estimates and action thresholds from prior-batch
 # visible feedback only. The ground-truth audit table is not used here.
 base=json.loads((ROOT/'simulation/public_ci_joint_v5_scenarios.json').read_text())
 with (ROOT/'data_public/neso_2026_10_09_to_16/regional_forecast.csv').open(newline='',encoding='utf-8') as f:ci_rows=list(csv.DictReader(f))
 ci={'London':[float(x['forecast_gco2_per_kwh']) for x in sorted((x for x in ci_rows if x['regionid']=='13' and x['region']=='London'),key=lambda x:x['from_utc'])],
     'Wales':[float(x['forecast_gco2_per_kwh']) for x in sorted((x for x in ci_rows if x['regionid']=='17' and x['region']=='Wales'),key=lambda x:x['from_utc'])]}
 params_by_scenario={}
 for x in summ:params_by_scenario[(x['scenario_id'],x['policy'])]=x
 for x in logs:
  ai=int(x['scenario_id'][1:]);rid=x['request_id'];rr=keyed(int(man['seed']),'request',rid);d=rr.random();home='London' if rr.random()<.5 else 'Wales'
  need(abs(float(x['difficulty'])-d)<1e-12,'synthetic visible feature does not match request seed')
  need(x['home_region']==home,'request location does not match paired seed')
  need(abs(float(x['grid_CI_g_per_kWh'])-ci[home][int(x['slot'])])<1e-8,'regional CI covariate is misaligned')
 # Rebuild evaluator-only quality and checker outcomes from the registered
 # random keys and scenario parameters; this confirms no hidden truth entered routing.
 for k,stages_for_request in groups.items():
  sid,pol,rid=k;ai=int(sid[1:]);sc=params_by_scenario[(sid,pol)];log=bylog[k]
  stages_for_request.sort(key=lambda x:int(x['stage']));previous=None
  for st in stages_for_request:
   stage=int(st['stage']);action=st['action'];p=base['actions'][action];d=float(log['difficulty'])
   mu=max(0.,min(1.,p['quality_intercept']+float(sc['quality_shift'])-p['quality_difficulty_slope']*d))
   q=max(0.,min(1.,keyed(int(man['seed']),ai,rid,action,stage-1,'quality').gauss(mu,p['quality_noise_sd'])))
   if stage>1:
    u=keyed(int(man['seed']),ai,rid,action,stage-1,'revision_transition').random();gain=float(sc['revision_gain'])
    if u<.65:q=min(1.,previous+gain)
    elif u<.90:q=previous
    else:q=max(0.,previous-gain/2)
   need(abs(float(st['latent_quality'])-q)<2e-8,'evaluator quality does not match registered scenario generator')
   truth=q>=.75;need((st['quality_pass']=='True')==truth,'quality threshold label mismatch')
   vp=st['verifier_pass']
   if vp!='':
    pu=(1-float(sc['FR'])) if truth else float(sc['FA'])
    expected=keyed(int(man['seed']),ai,rid,action,stage-1,'verifier').random()<pu
    need((vp=='True')==expected,'verifier outcome does not match FA/FR rule')
   user_u=keyed(int(man['seed']),ai,rid,action,stage-1,'user').random()
   dissatisfied=(not truth if user_u>=.1 else truth)
   f=feedback_by_key[(*k,str(stage))]
   need((f['user_dissatisfied']=='True')==dissatisfied,'user feedback outcome does not match its declared noise')
   previous=q
 for logkey,logrow in bylog.items():
  sc=params_by_scenario[(logrow['scenario_id'],logrow['policy'])]
  executed=groups.get(logkey,[]);cost=energy=0.
  for st in executed:
   p=base['actions'][st['action']]
   cost+=float(p['cost_units'])*(float(sc['large_cost_multiplier']) if st['action']=='large' else 1.)
   energy+=float(p['it_energy_kwh'])
   if st['verifier_pass']!='':cost+=.02;energy+=.00002
  need(abs(float(logrow['cost'])-cost)<1e-8,'per-request cost ledger mismatch')
  need(abs(float(logrow['energy_kWh'])-energy)<1e-9,'per-request energy ledger mismatch')
 learn_policies={'feedback_mean','feedback_lcb','feedback_no_verifier','combined','combined_no_uncertainty','combined_no_revision'}
 by_group={}
 for x in logs:by_group.setdefault((x['scenario_id'],x['policy']),[]).append(x)
 fb_group={}
 for x in feedback:fb_group.setdefault((x['scenario_id'],x['policy']),[]).append(x)
 replayed=0
 for (sid,pol),items in by_group.items():
  params=next(x for x in summ if x['scenario_id']==sid and x['policy']==pol)
  fa=float(params['FA']);fr=float(params['FR']);counts={(b,a):[3,1] for b in ('low','high') for a in ('small','large')}
  grouped={}
  for x in items:grouped.setdefault(int(x['slot']),[]).append(x)
  fslots={}
  for x in fb_group.get((sid,pol),[]):fslots.setdefault(int(x['slot']),[]).append(x)
  for slot,decisions in sorted(grouped.items()):
   for x in decisions:
    b=x['difficulty_bin'];s,fail=counts[(b,'small')];n=s+fail;raw=s/n;lo=wilson_lower(s,n)
    ef,er=(.1,.1) if pol=='feedback_no_verifier' else (fa,fr)
    mean=max(0.,min(1.,(raw-ef)/(1-ef-er)));lcb=max(0.,min(1.,(lo-ef)/(1-ef-er)))
    need(abs(float(x['router_small_mean'])-mean)<2e-6,'router mean estimate cannot be replayed')
    need(abs(float(x['router_small_lcb'])-lcb)<2e-6,'router uncertainty bound cannot be replayed')
    expected=None
    if pol in ('feedback_mean','feedback_no_verifier','combined_no_uncertainty'):expected='small' if mean>=.75 else 'large'
    elif pol in ('feedback_lcb','combined','combined_no_learning','combined_no_revision'):expected='small' if lcb>=.75 else 'large'
    elif pol in ('always_small','direct_small','revise_once','revise_multi'):expected='small'
    elif pol=='always_large':expected='large'
    adaptive={'feedback_mean','feedback_lcb','feedback_no_verifier','combined','combined_no_learning','combined_no_uncertainty','combined_no_revision'}
    scenario_index=int(sid[1:]);key='|'.join(map(str,(int(man['seed']),scenario_index,x['request_id'],'exploration'))).encode()
    expected_explore=(pol in adaptive and random.Random(int.from_bytes(hashlib.blake2b(key,digest_size=8).digest(),'big')).random()<.10)
    need((x['exploration']=='True')==expected_explore,'exploration assignment is inconsistent with seeded design')
    if expected_explore:expected='small'
    if expected is not None:need(x['chosen_action']==expected,'chosen action disagrees with router information set')
    need(int(x['router_feedback_available_through_slot'])<slot,'non-causal feedback boundary')
    replayed+=1
   if pol in learn_policies:
    for f in fslots.get(slot,[]):
     observed=(f['user_dissatisfied']!='True') if pol=='feedback_no_verifier' else (f['verifier_pass']=='True')
     c=counts[(f['difficulty_bin'],f['action'])];c[0]+=int(observed);c[1]+=int(not observed)
 need(set(groups).issubset(set(bylog)),'audit row lacks router request record')
 for k,x in bylog.items():need(int(x['stages'])==len(groups.get(k,[])),'stage count disagrees')
 summary={(x['scenario_id'],x['policy']):x for x in summ}
 capacity={}
 for x in audit:
  request=bylog[(x['scenario_id'],x['policy'],x['request_id'])]
  key=(x['scenario_id'],x['policy'],request['slot'],x['region'])
  capacity[key]=capacity.get(key,0.)+float(x['service_seconds'])
 for used in capacity.values():need(used<=3600+1e-9,'aggregate batch server-work budget exceeded')
 logs_by_summary={}
 for x in logs:logs_by_summary.setdefault((x['scenario_id'],x['policy']),[]).append(x)
 checks=0
 for k,s in summary.items():
  rr=logs_by_summary.get(k,[])
  need(int(s['N_arrivals'])==len(rr),'arrival count mismatch')
  served=sum(x['served']=='True' for x in rr);valid=sum(x['valid']=='True' for x in rr)
  need(int(s['N_served'])==served,'served total mismatch');need(int(s['N_valid'])==valid,'valid total mismatch')
  need(valid<=served,'valid answers exceed delivered answers')
  need(abs(float(s['valid_rate'])-valid/len(rr))<1e-10,'valid-rate denominator mismatch')
  cost=sum(float(x['cost']) for x in rr);energy=sum(float(x['energy_kWh']) for x in rr)
  need(abs(float(s['system_cost_units'])-cost)<1e-7,'cost sum mismatch')
  need(abs(float(s['system_energy_kWh'])-energy)<1e-8,'energy sum mismatch')
  for x in rr:need(abs(float(x['carbon_g'])-float(x['energy_kWh'])*float(x['grid_CI_g_per_kWh'])*1.45)<2e-8,'per-request carbon formula mismatch')
  carbon=sum(float(x['carbon_g']) for x in rr)
  need(abs(float(s['system_carbon_g'])-carbon)<1e-7,'carbon sum mismatch')
  checks+=len(rr)
 report={'status':'passed','synthetic_only':True,'router_log_rows':len(logs),'router_feedback_rows':len(feedback),'evaluator_audit_rows':len(audit),'summary_rows':len(summ),'decision_and_summary_records_checked':checks,'online_router_decisions_replayed':replayed,'capacity_groups_checked':len(capacity),'verified':['runner/input/result hashes','latent outcomes absent from router logs','posterior and action choices independently replayed from earlier-batch feedback','revision feedback is stage-visible and joins the evaluator ledger','revision cap','aggregate regional batch capacity','delivered-valid denominator relationship','cost, energy and carbon sums'],'limitations':['Does not validate empirical calibration or deployment applicability.','Capacity validation is limited to the declared aggregate batch budget.']}
 man['status']='run_and_independent_check_passed'
 report['manifest_status']=man['status']
 (out/'independent_check.json').write_text(json.dumps(report,indent=2)+'\n')
 man['independent_report_sha256']=sha(out/'independent_check.json')
 (out/'run_manifest.json').write_text(json.dumps(man,indent=2)+'\n')
 return report
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,default=ROOT/'results/feedback_uncertainty_revision_v5');a=ap.parse_args();print(json.dumps(check(a.input),indent=2))
