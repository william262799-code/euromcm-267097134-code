"""Independent integrity and accounting checks for the v5 stress experiment."""
import csv,hashlib,json,math
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/v5_robustness_rebound_subgroup'
RUNNER=ROOT/'simulation/v5_robustness_rebound_subgroup_experiment.py'
BASE=ROOT/'simulation/public_ci_joint_v5_scenarios.json'
CI_FILE=ROOT/'data_public/neso_2026_10_09_to_16/regional_forecast.csv'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(name):
    with (OUT/name).open(newline='',encoding='utf-8') as f: return list(csv.DictReader(f))
def near(a,b,tol=1e-8): return abs(float(a)-float(b))<=tol*max(1.,abs(float(a)),abs(float(b)))

def main():
    m=json.loads((OUT/'run_manifest.json').read_text()); cfg=json.loads((OUT/'scenario_config.json').read_text())
    assert m['runner_sha256']==sha(RUNNER)
    assert m['base_profile_sha256']==sha(BASE) and m['NESO_data_sha256']==sha(CI_FILE)
    assert m['checker_sha256']==sha(Path(__file__))
    for fn,h in m['result_hashes'].items(): assert sha(OUT/fn)==h,fn
    if 'readme_sha256' in m: assert sha(OUT/'README.md')==m['readme_sha256']
    if 'independent_check_result_sha256' in m: assert sha(OUT/'independent_check_result.json')==m['independent_check_result_sha256']
    assert m['synthetic_only'] and cfg['claim'].startswith('synthetic')
    req=rows('request_outcomes_evaluator_only.csv'); stages=rows('stage_ledger_evaluator_only.csv')
    sums=rows('seed_policy_summary.csv'); groups=rows('subgroup_summary_by_seed.csv'); feedback=rows('router_feedback_log.csv')
    base=json.loads(BASE.read_text()); profiles=base['actions']; ci_rows=list(csv.DictReader(CI_FILE.open(newline='',encoding='utf-8')))
    ci={reg:[float(x['forecast_gco2_per_kwh']) for x in sorted((x for x in ci_rows if x['region']==reg),key=lambda x:x['from_utc'])] for reg in ('London','Wales')}
    slot_s=1800.;pue=1.45
    def int_ci(series,t):
        if t<=0:return 0.
        idx=min(len(series)-1,int(t//slot_s))
        return sum(series[:idx])*slot_s+(t-idx*slot_s)*series[idx]
    key=lambda x:(x['scenario'],x['seed'],x['policy'])
    byreq={}
    for x in req:
        assert x['synthetic_only']=='True'
        assert x['valid'] in ('True','False') and x['served'] in ('True','False')
        assert float(x['difficulty'])>=0 and float(x['difficulty'])<=1
        byreq.setdefault(key(x),[]).append(x)
    bystage={}
    for x in stages:
        k=(*key(x),x['request_id']); bystage.setdefault(k,[]).append(x)
        assert x['action'] in ('small','large') and x['region'] in ('London','Wales')
        assert float(x['end'])>float(x['start']) and int(x['server']) in (0,1)
        assert x['quality_pass'] in ('True','False')
        vp=x['verifier_pass']
        assert vp in ('True','False','')
    # Capacity is checked independently as non-overlapping server intervals.
    server={}
    for x in stages: server.setdefault((x['scenario'],x['seed'],x['policy'],x['region'],x['server']),[]).append(x)
    for k,xs in server.items():
        xs.sort(key=lambda z:float(z['start']))
        for a,b in zip(xs,xs[1:]): assert float(a['end'])<=float(b['start'])+1e-7,('overlap',k,a,b)
    summary_by={key(x):x for x in sums}
    assert len(summary_by)==len(sums)
    for k,xs in byreq.items():
        s=summary_by[k]; n=len(xs)
        assert int(s['N_arrivals'])==n
        valid=sum(x['valid']=='True' for x in xs);served=sum(x['served']=='True' for x in xs)
        assert int(s['N_valid'])==valid and int(s['N_served'])==served
        assert near(s['valid_rate'],valid/n) and near(s['served_rate'],served/n)
        assert near(s['system_cost_units'],sum(float(x['cost']) for x in xs))
        assert near(s['system_energy_kWh'],sum(float(x['energy_kWh']) for x in xs))
        assert near(s['system_carbon_g'],sum(float(x['carbon_g']) for x in xs))
        served_rows=[x for x in xs if x['served']=='True']
        assert near(s['mean_response_s'],sum(float(x['response_s']) for x in served_rows)/len(served_rows) if served_rows else 0.)
        seed_stages=[z for x in xs for z in bystage.get((*k,x['request_id']),[])]
        assert near(s['mean_route_regret_g'],sum(float(z['route_regret_g']) for z in seed_stages)/len(seed_stages) if seed_stages else 0.)
        for x in xs:
            st=sorted(bystage.get((*k,x['request_id']),[]),key=lambda z:int(z['stage']))
            assert int(x['stages'])==len(st)
            assert near(x['cost'],sum(float(z['cost']) for z in st))
            assert near(x['energy_kWh'],sum(float(z['energy']) for z in st))
            assert near(x['carbon_g'],sum(float(z['actual_carbon_g']) for z in st))
            # Recompute carbon from the pinned regional series and action profile.
            for z in st:
                a=profiles[z['action']];start=float(z['start']);end=float(z['end']);duration=float(a['service_seconds'])
                expected=a['it_energy_kwh']*pue*(int_ci(ci[z['region']],end)-int_ci(ci[z['region']],start))/duration
                if k[2] in ('cascade_joint_carbon','feedback_lcb_joint'):
                    expected+=.00002*pue*ci[z['region']][min(335,int((end+1)//slot_s))]
                if z['region']!=x['home_region']:
                    transfer=.007 if x['home_region']=='London' else .008
                    t=min(335,int((float(x['arrival_s'])+transfer/2)//slot_s))
                    expected+=.0002*.5*(ci[x['home_region']][t]+ci[z['region']][t])
                    assert near(float(z['energy'])-a['it_energy_kwh']-(.00002 if k[2] in ('cascade_joint_carbon','feedback_lcb_joint') else 0),.0002)
                else:
                    assert near(float(z['energy'])-a['it_energy_kwh']-(.00002 if k[2] in ('cascade_joint_carbon','feedback_lcb_joint') else 0),0.)
                assert near(z['actual_carbon_g'],expected,1e-7),('carbon formula',z['request_id'],z['stage'],z['actual_carbon_g'],expected)
                assert float(z['route_regret_g'])>=-1e-8
                assert near(float(z['route_regret_g']),float(z['actual_carbon_g'])-float(z['oracle_best_actual_carbon_g']),1e-7)
            if x['served']=='True':
                assert st and x['selected_action']==st[-1]['action']
            if x['valid']=='True':
                assert st and st[-1]['quality_pass']=='True' and float(x['arrival_s'])+float(x['response_s'])<=float(x['deadline_s'])+1e-7
    # Subgroup rates/costs must be reproducible from evaluator ledger.
    group_by={(x['scenario'],x['seed'],x['policy'],x['group']):x for x in groups}
    for k,xs in byreq.items():
        for g in ('standard','complex'):
            ys=[x for x in xs if x['group']==g]
            if not ys: continue
            z=group_by[(*k,g)];n=len(ys);v=sum(x['valid']=='True' for x in ys);sv=sum(x['served']=='True' for x in ys)
            assert int(z['N_arrivals'])==n and near(z['valid_rate'],v/n) and near(z['served_rate'],sv/n)
    # The router-facing log may contain verifier feedback only, never evaluator truth.
    for x in feedback:
        assert set(x).issubset({'scenario','seed','policy','request_id','slot','stage','action','verifier_pass','feedback_available_after_stage','model_update_after_slot'})
        assert x['feedback_available_after_stage']=='True'
        assert x['verifier_pass'] in ('True','False')
        assert x['model_update_after_slot'] in ('never',str(int(x['slot'])+1))
        assert (x['scenario'],x['seed'],x['policy'],x['request_id']) in bystage
    # One stage for fixed baselines, at most two for cascade policies.
    max_stage={p:(1 if p.endswith('_local') else 2) for p in cfg['policies']}
    for k,xs in byreq.items():
        for x in xs: assert int(x['stages'])<=max_stage[k[2]]
    # Rebuild across-seed means and small-sample t intervals from seed-level output.
    import statistics
    aggregate=rows('factor_summary_mean_ci.csv')
    agg_by={(x['scenario'],x['policy']):x for x in aggregate}
    fields=('N_arrivals','valid_rate','served_rate','system_cost_units','cost_per_valid','mean_response_s','mean_route_regret_g','system_energy_kWh','system_carbon_g','carbon_per_arrival_g','carbon_per_valid_g','deadline_or_capacity_miss_rate','revision_rate')
    for k,a in agg_by.items():
        ys=[x for x in sums if (x['scenario'],x['policy'])==k]
        assert len(ys)==5 and int(a['seed_count'])==5
        for f in fields:
            vals=[float(x[f]) for x in ys if x[f]!=''];mean=statistics.mean(vals);se=statistics.stdev(vals)/math.sqrt(len(vals))
            assert near(a[f+'_mean'],mean) and near(a[f+'_ci95_low'],mean-2.776*se) and near(a[f+'_ci95_high'],mean+2.776*se)
    return {'status':'PASS','request_rows':len(req),'stage_rows':len(stages),'seed_policy_runs':len(sums),'feedback_rows':len(feedback),'capacity_overlap_count':0,'ledger_reconciliations':'PASS','router_information_boundary':'PASS','source_and_artifact_hashes':'PASS'}

if __name__=='__main__': print(json.dumps(main(),indent=2))
