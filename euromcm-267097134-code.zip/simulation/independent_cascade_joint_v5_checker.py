"""Independent event/resource and accounting checker for conditional cascade run; no simulator imports."""
import argparse,bisect,csv,hashlib,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];DATA=ROOT/'data_public/neso_2026_10_09_to_16/regional_forecast.csv';MAN=DATA.parent/'manifest.json';BASE=ROOT/'simulation/public_ci_joint_v5_scenarios.json';RTT=ROOT/'data_public/azure_rtt_2026-07-30/uk_south_uk_west_p50.json';SLOT=1800;REGIONS=('london_uk_south','cardiff_uk_west');POLICIES=('always_small_local','always_large_local','quality_gated_local_cost','quality_gated_joint_carbon','cascade_local','cascade_joint_carbon')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 with Path(p).open(newline='',encoding='utf8') as f:return list(csv.DictReader(f))
def need(x,m):
 if not x:raise AssertionError(m)
def close(a,b,tol=1e-7):return abs(float(a)-float(b))<=tol
CI_PREFIX={}
def integrated_ci(region,t):
 pref,series=CI_PREFIX[region];end=len(series)*SLOT
 if t>=end:return pref[-1]+(t-end)*series[-1]
 if t<=0:return 0.
 slot=min(len(series)-1,int(t//SLOT))
 return pref[slot]+(t-slot*SLOT)*series[slot]
def percentile(v,p):
 if not v:return ''
 z=sorted(float(x) for x in v);return z[max(0,math.ceil(p*len(z))-1)]
def faithful_qhat(sid,rid,action,qhmap,gate,policy,assignment,base):
 qh=qhmap[(sid,rid,action)]
 p=base['actions'][action];expected=max(0.,min(1.,float(p['quality_intercept'])+float(assignment['quality_shift_design'])-float(p['quality_difficulty_slope'])*float(assignment['difficulty'])))
 if not close(expected,qh):return False
 if policy.startswith('quality_gated') and qh+1e-12<gate:return False
 return True
def window_intervals(prior,earliest,latest,duration,max_prior_duration):
 lo=bisect.bisect_left(prior,(earliest-max_prior_duration-1e-9,-math.inf))
 hi=bisect.bisect_left(prior,(latest+duration-1e-9,-math.inf))
 return [(a,b) for a,b in prior[lo:hi] if b>earliest+1e-9]
def interval_free(prior,start,end):
 i=bisect.bisect_right(prior,(start+1e-9,math.inf))
 if i and prior[i-1][1]>start+1e-9:return False
 if i<len(prior) and prior[i][0]<end-1e-9:return False
 return True
def earliest_feasible_start(earliest,latest,can_wait,prior,duration,max_prior_duration):
 if not can_wait:return earliest if earliest<=latest and interval_free(prior,earliest,earliest+duration) else None
 start=earliest
 for a,b in window_intervals(prior,earliest,latest,duration,max_prior_duration):
  if b<=start+1e-9:continue
  if start+duration<=a+1e-9:break
  start=b
  if start>latest+1e-9:return None
 return start if start<=latest+1e-9 and interval_free(prior,start,start+duration) else None
def critical_starts(earliest,latest,can_wait,prior,duration,check_s,rtt_s,max_prior_duration):
 """Independent enumeration of feasibility/objective breakpoints."""
 if not can_wait:return [earliest]
 cand={earliest,latest}
 relevant=window_intervals(prior,earliest,latest,duration,max_prior_duration)
 for a,b in relevant:cand.add(b);cand.add(a-duration)
 span=max(duration+check_s,rtt_s,0.)
 for k in range(max(0,int((earliest-span)//SLOT)-1),int(math.ceil((latest+span)/SLOT))+2):
  g=k*SLOT
  for z in (g,g-duration):
   if earliest-1e-9<=z<=latest+1e-9:
    cand.add(z);left=math.nextafter(z,-math.inf)
    if earliest<=left<=latest:cand.add(left)
  if check_s:
   z=g-duration-check_s/2
   if earliest-1e-9<=z<=latest+1e-9:
    cand.add(z);left=math.nextafter(z,-math.inf)
    if earliest<=left<=latest:cand.add(left)
  if rtt_s:
   z=g+rtt_s/2
   if earliest-1e-9<=z<=latest+1e-9:
    cand.add(z);left=math.nextafter(z,-math.inf)
    if earliest<=left<=latest:cand.add(left)
 return sorted(x for x in cand if earliest-1e-9<=x<=latest+1e-9)
def replay_candidate_set(r,action,policy,book,ready,with_check,large_mult,base,assumptions,ci):
 prof=base['actions'][action];check_s=2. if with_check else 0.;pue=float(assumptions['PUE']);regions=[r['home_region']] if policy in ('always_small_local','always_large_local','quality_gated_local_cost','cascade_local') else r['allowed_regions'].split('|');out=[]
 home='london_uk_south' if r['home_region']=='london_uk_south' else 'cardiff_uk_west';gate=float(r['quality_gate']);arrival=float(r['arrival_s']);deadline=float(r['deadline_s'])
 for region in regions:
  if region not in r['allowed_regions'].split('|'):continue
  tr=0. if region==home else ((7 if home==REGIONS[0] else 8)/1000.)
  earliest=(arrival if ready is None else ready)+tr;latest=deadline-float(prof['service_seconds'])-check_s
  if latest<earliest:continue
  for server,prior in enumerate(book[region]):
   max_prior_duration=max(float(x['service_seconds']) for x in base['actions'].values())
   if policy in ('cascade_joint_carbon','quality_gated_joint_carbon'):
    starts=critical_starts(earliest,latest,r['delay_allowed']=='True',prior,float(prof['service_seconds']),check_s,tr,max_prior_duration)
   else:
    first=earliest_feasible_start(earliest,latest,r['delay_allowed']=='True',prior,float(prof['service_seconds']),max_prior_duration)
    starts=[] if first is None else [first]
   for start in starts:
    end=start+float(prof['service_seconds'])
    if end+check_s>deadline+1e-8 or not interval_free(prior,start,end):continue
    duration=float(prof['service_seconds']);power=float(prof['it_energy_kwh'])/duration
    # O(1) prefix integral, matching the runner's summation order.
    service_gross=power*pue*(integrated_ci(region,end)-integrated_ci(region,start))
    check_ci=0.
    if with_check:check_ci=.00002*pue*ci[region][min(335,int((end+1.)//SLOT))]
    netk=float(assumptions['network_energy_kWh_per_remote_stage']) if tr else 0.;ng=0.
    if netk:
     slot=min(335,int((start-tr/2)//SLOT));omega=float(assumptions['network_CI_split_source_target'][0]);ng=netk*(omega*ci[home][slot]+(1-omega)*ci[region][slot])
    cost=float(prof['cost_units'])*(large_mult if action=='large' else 1.)+(float(assumptions['profiles']['check']['cost_units']) if with_check else 0.)+(float(assumptions['network_cost_units_per_remote_stage']) if tr else 0.)
    carbon=service_gross+check_ci+ng;response=end+check_s-arrival
    if policy in ('cascade_joint_carbon','quality_gated_joint_carbon'):key=(carbon,cost,response,action,region,server,start)
    else:key=(cost,response,carbon,action,region,server,start)
    out.append((key,dict(action=action,region=region,server=server,start=start,end=end,cost=cost,carbon=carbon,response=response)))
 return out
def check(out):
 out=Path(out);cfg=json.loads((out/'scenario_config.json').read_text());base=json.loads(BASE.read_text());ci={}
 need(sha(DATA)==json.loads(MAN.read_text())['processed_sha256'],'NESO source hash mismatch')
 with DATA.open(newline='') as f:source=list(csv.DictReader(f))
 for reg,rid,label in ((REGIONS[0],'13','London'),(REGIONS[1],'17','Wales')):
  x=sorted((r for r in source if r['regionid']==rid and r['region']==label),key=lambda r:r['from_utc']);need(len(x)==336,'CI series length mismatch');ci[reg]=[float(r['forecast_gco2_per_kwh']) for r in x]
 for reg,series in ci.items():
  pref=[0.]
  for value in series:pref.append(pref[-1]+value*SLOT)
  CI_PREFIX[reg]=(pref,series)
 rtt=json.loads(RTT.read_text());need(rtt['directional_values']=={'UK South to UK West':7,'UK West to UK South':8},'RTT source mismatch')
 man=json.loads((out/'run_manifest.json').read_text());need(man['status'] in ('run_complete_pending_independent_checker','run_and_independent_checker_passed'),'unexpected run manifest status');need(man['independent_checker_sha256']==sha(Path(__file__)),'independent checker source hash mismatch');need(man['synthetic_only'] is True,'synthetic boundary missing');need(man['NESO_sha256']==sha(DATA),'manifest NESO hash mismatch');need(man['Azure_RTT_sha256']==sha(RTT),'manifest RTT hash mismatch');need(man['runner_sha256']==sha(ROOT/'simulation/cascade_joint_v5_conditional.py'),'runner source hash mismatch');need(man['scenario_config_sha256']==sha(out/'scenario_config.json'),'scenario config hash mismatch')
 for name,h in man['result_hashes'].items():need(sha(out/name)==h,'result hash mismatch '+name)
 ass=read(out/'cascade_assignments.csv');stages=read(out/'cascade_stage_ledger.csv');audit=read(out/'cascade_audit_outcomes.csv');summ=read(out/'cascade_summary.csv');common=read(out/'cascade_common_served.csv')
 amap={(r['scenario_id'],r['request_id'],r['action']):float(r['actual_quality']) for r in audit};qhmap={(r['scenario_id'],r['request_id'],r['action']):float(r['qhat']) for r in audit};need(len(amap)==len(audit),'duplicate audit outcomes')
 smap={(x['scenario_id'],x['policy']):x for x in summ};need(len(smap)==36*len(POLICIES),'summary row count mismatch');need(len(common)==36*len(POLICIES),'common summary row count mismatch')
 groups={(r['scenario_id'],r['policy'],r['request_id']):r for r in ass};stagegroups={}
 for x in stages:stagegroups.setdefault((x['scenario_id'],x['policy'],x['request_id']),[]).append(x)
 expected_stage_count=0;checked_intervals=0
 # Exact intervals must fit server count and deadlines; transitions are small->large once.
 for k,rows in stagegroups.items():
  rows.sort(key=lambda x:int(x['stage']));sid,pol,rid=k;rr=groups[k];need(len(rows)<=2,'more than one escalation');need([x['action'] for x in rows]==(['small','large'] if len(rows)==2 else [rows[0]['action']]),'invalid action progression')
  if pol=='always_small_local':need(len(rows)==1 and rows[0]['action']=='small','small baseline action mismatch')
  if pol=='always_large_local':need(len(rows)==1 and rows[0]['action']=='large','large baseline action mismatch')
  if pol.startswith('quality_gated'):need(len(rows)==1 and rows[0]['action'] in ('small','large'),'quality-gated direct action invalid')
  if pol.startswith('cascade'):need(rows[0]['action']=='small','cascade did not start small')
  prev=None
  for x in rows:
   expected_stage_count+=1;stage=int(x['stage']);action=x['action'];region=x['region'];a=float(x['start']);b=float(x['end']);arr=float(rr['arrival_s']);deadline=float(rr['deadline_s']);tr=float(x['transfer_s'])
   need(region in rr['allowed_regions'].split('|'),'residency violated');check_s=2. if x['with_check']=='True' else 0.;need(b>a and b+check_s<=deadline+1e-7,'deadline/service/check interval violation');need(close(b-a,base['actions'][action]['service_seconds']),'service duration mismatch')
   need(close(tr,0 if region==rr['home_region'] else (.007 if rr['home_region']==REGIONS[0] else .008)),'transfer RTT mismatch')
   if prev is None:
    need(a>=arr+tr-1e-8,'first stage precedes arrival/transfer')
    if rr['delay_allowed']=='False':need(close(a,arr+tr),'delay-forbidden first stage waited')
   else:
    need(action=='large' and a>=float(prev['end'])+2+tr-1e-8,'upgrade failed to wait for prior check/transfer')
    if rr['delay_allowed']=='False':need(close(a,float(prev['end'])+2+tr),'delay-forbidden upgrade waited')
   need(int(x['server']) in (0,1),'server id outside capacity')
   # quality truth and noisy verifier recomputed from audit value and scenario parameters
   gate=float(rr['quality_gate']);q=amap[(sid,rid,action)];truth=q>=gate
   need(faithful_qhat(sid,rid,action,qhmap,gate,pol,rr,base),'quality gate/routing mismatch')
   checked=pol.startswith('cascade')
   if checked:
    need((x['quality_truth']=='True')==truth,'stage quality truth mismatch')
    fa=float(rr['FA']);fr=float(rr['FR']);need(fa+fr<1,'invalid FA/FR pair')
    import random
    key='|'.join(map(str,(int(man['seed']),'v',fa,fr,rid,action))).encode();u=random.Random(int.from_bytes(hashlib.blake2b(key,digest_size=8).digest(),'big')).random();expected=u<((1-fr) if truth else fa)
    need((x['verifier_pass']=='True')==expected,'verifier outcome mismatch')
   else:need(x['verifier_pass']=='','direct baseline unexpectedly used verifier')
   prof=base['actions'][action];energy=float(prof['it_energy_kwh']);duration=float(prof['service_seconds']);t=a;g=0.
   while t<b-1e-9:
    ix=min(335,int(t//SLOT));edge=min(b,(ix+1)*SLOT);g+=energy/duration*(edge-t)*1.45*ci[region][ix];t=edge
   ix=min(335,int((b+1.)//SLOT));checkg=(.00002*1.45*ci[region][ix]) if x['with_check']=='True' else 0.;ixnet=min(335,int(((a-tr+a)/2)//SLOT));netk=.0002 if tr else 0.;netg=netk*.5*(ci[rr['home_region']][ixnet]+ci[region][ixnet])
   need(close(x['service_g'],g) and close(x['checker_g'],checkg) and close(x['network_g'],netg),'stage carbon ledger mismatch')
   need(close(x['IT_kWh'],energy+(.00002 if x['with_check']=='True' else 0)) and close(x['network_kWh'],netk),'stage energy ledger mismatch')
   need(close(x['cost'],prof['cost_units']*(float(rr['large_cost_multiplier']) if action=='large' else 1)+(.02 if x['with_check']=='True' else 0)+(.2 if tr else 0)),'stage cost mismatch')
   prev=x;checked_intervals+=1
  last=rows[-1]
  if len(rows)==2:need(rows[0]['verifier_pass']=='False','escalated despite first-stage accept')
  elif pol.startswith('cascade') and last['verifier_pass']=='False':need(rr['served']=='False','failed cascade delivered rejected answer')
  if rr['served']=='True':
   if pol.startswith('cascade'):need(last['verifier_pass']=='True','cascade delivered rejected final stage')
   need(rr['selected_action']==last['action'],'delivered action differs from final stage')
 # Independently replay the per-request local tuple choice. This deliberately
 # does not claim cross-request/global optimality or full cascade optimality.
 objective_decisions_checked=0;no_feasible_decisions_checked=0
 assumptions=cfg
 by_sp={}
 for (sid,pol,rid),rr in groups.items():by_sp.setdefault((sid,pol),[]).append(rr)
 for (sid,pol),requests in by_sp.items():
  requests.sort(key=lambda z:(float(z['arrival_s']),z['request_id']))
  book={reg:[[],[]] for reg in REGIONS}
  for rr in requests:
   rid=rr['request_id'];sg=stagegroups.get((sid,pol,rid),[]);sg.sort(key=lambda x:int(x['stage']))
   large_mult=float(rr['large_cost_multiplier']);gate=float(rr['quality_gate'])
   is_cascade=pol.startswith('cascade')
   if is_cascade:
    acts=('small',)
   elif pol.startswith('quality_gated'):
    acts=('small','large')
   else:
    acts=('small',) if pol=='always_small_local' else ('large',)
   winners=[]
   for action in acts:
    if pol.startswith('quality_gated') and qhmap[(sid,rid,action)]+1e-12<gate:continue
    cand=replay_candidate_set(rr,action,pol,book,None,pol.startswith('cascade'),large_mult,base,assumptions,ci)
    if cand:
     winner=min(cand,key=lambda x:x[0]);winners.append((action,winner))
   if not winners:
    need(not sg,f'candidate replay found no first-stage candidate but runner executed one: {sid}/{pol}/{rid}')
    need(rr['served']=='False',f'candidate replay found no feasible first-stage candidate but request served: {sid}/{pol}/{rid}')
    no_feasible_decisions_checked+=1
    continue
   if is_cascade:
    action,expected=winners[0]
    logged=sg[0]
    need(close(logged['start'],expected[1]['start']),f'local candidate rank mismatch at first stage {sid}/{pol}/{rid}: logged={logged["start"]} expected={expected[1]["start"]}')
    need(logged['action']==action and logged['region']==expected[1]['region'] and int(logged['server'])==expected[1]['server'],f'local candidate tuple mismatch at first stage {sid}/{pol}/{rid}')
    objective_decisions_checked+=1
    bisect.insort(book[logged['region']][int(logged['server'])],(float(logged['start']),float(logged['end'])))
    if logged['verifier_pass']=='False':
     ready=float(logged['end'])+float(logged['check_time'])
     cand2=replay_candidate_set(rr,'large',pol,book,ready,True,large_mult,base,assumptions,ci)
     if not cand2:
      need(len(sg)==1 and rr['served']=='False',f'upgrade infeasible replay mismatch {sid}/{pol}/{rid}')
      no_feasible_decisions_checked+=1
     else:
      exp2=min(cand2,key=lambda x:x[0]);need(len(sg)==2,f'replay found feasible upgrade but runner omitted it {sid}/{pol}/{rid}')
      logged2=sg[1]
      need(close(logged2['start'],exp2[1]['start']),f'local candidate rank mismatch at upgrade {sid}/{pol}/{rid}: logged={logged2["start"]} expected={exp2[1]["start"]}')
      need(logged2['region']==exp2[1]['region'] and int(logged2['server'])==exp2[1]['server'] and logged2['action']=='large',f'upgrade candidate tuple mismatch {sid}/{pol}/{rid}')
      objective_decisions_checked+=1
      bisect.insort(book[logged2['region']][int(logged2['server'])],(float(logged2['start']),float(logged2['end'])))
    else:
     need(len(sg)==1,f'runner executed upgrade despite accepted first stage {sid}/{pol}/{rid}')
   else:
    # For direct policies, each action is independently reduced to its best
    # region/server/start, then the declared policy tuple selects an action.
    best=[]
    for action,winner in winners:
     d=winner[1]
     key=((d['carbon'],d['cost'],d['response'],action,d['region'],d['server'],d['start'])
          if pol=='quality_gated_joint_carbon' else
          (d['cost'],d['response'],d['carbon'],action,d['region'],d['server'],d['start']))
     best.append((key,action,winner))
    _,action,expected=min(best,key=lambda x:x[0]);need(len(sg)==1,f'direct replay found candidate count mismatch {sid}/{pol}/{rid}')
    logged=sg[0]
    need(close(logged['start'],expected[1]['start']),f'local candidate rank mismatch {sid}/{pol}/{rid}: logged={logged["start"]} expected={expected[1]["start"]}')
    need(logged['action']==action and logged['region']==expected[1]['region'] and int(logged['server'])==expected[1]['server'],f'direct candidate tuple mismatch {sid}/{pol}/{rid}')
    objective_decisions_checked+=1
    bisect.insort(book[logged['region']][int(logged['server'])],(float(logged['start']),float(logged['end'])))
 # Verify global per-server non-overlap from raw stage intervals.
 books={}
 for x in stages:books.setdefault((x['scenario_id'],x['policy'],x['region'],int(x['server'])),[]).append((float(x['start']),float(x['end'])))
 for key,iv in books.items():
  iv.sort()
  for left,right in zip(iv,iv[1:]):need(left[1]<=right[0]+1e-9,'server interval overlap '+str(key))
 # No assignment row can be missing a stage or vice versa.
 need(set(stagegroups)<=set(groups),'orphan stage log')
 for k,r in groups.items():
  stages_for=stagegroups.get(k,[]);need(int(r['attempted_stages'])==len(stages_for),'attempt count mismatch')
  need((r['upgrade_attempted']=='True')==(len(stages_for)==2),'upgrade indicator mismatch')
  if r['served']=='True':need(bool(stages_for),'served without stage');need((not r['policy'].startswith('cascade')) or stages_for[-1]['verifier_pass']=='True','cascade served without accepted stage')
  else:need(not r['selected_action'],'unserved row has selected delivery')
  if stages_for:
   need(close(r['response_s'],float(stages_for[-1]['end'])+float(stages_for[-1]['check_time'])-float(r['arrival_s'])),'response duration mismatch')
   total_cost=sum(float(x['cost']) for x in stages_for);total_g=sum(float(x['service_g'])+float(x['checker_g'])+float(x['network_g']) for x in stages_for);eg=sum(float(x['IT_kWh']) for x in stages_for);ng=sum(float(x['network_kWh']) for x in stages_for)
  else:need(r['response_s']=='','unserved without stage has response');total_cost=total_g=eg=ng=0.
  need(close(r['total_cost_units'],total_cost) and close(r['total_carbon_g'],total_g) and close(r['IT_energy_kWh'],eg) and close(r['network_energy_kWh'],ng),'assignment aggregate ledger mismatch')
  if r['served']=='True':
   q=amap[(r['scenario_id'],r['request_id'],r['selected_action'])];valid=q>=float(r['quality_gate']) and float(r['response_s'])<=float(r['deadline_s'])-float(r['arrival_s'])+1e-7
   need((r['valid']=='True')==valid,'valid answer definition mismatch')
 # Independently rebuild summary aggregates.
 assigngroups={}
 for x in ass:assigngroups.setdefault((x['scenario_id'],x['policy']),[]).append(x)
 for (sid,policy),s in smap.items():
  rows=assigngroups[(sid,policy)];n=len(rows);sv=[x for x in rows if x['served']=='True'];va=[x for x in rows if x['valid']=='True']
  checks={'N_arrivals':n,'N_served':len(sv),'N_unserved':n-len(sv),'N_valid':len(va),'upgrade_attempts':sum(x['upgrade_attempted']=='True' for x in rows),'system_cost_units':sum(float(x['total_cost_units']) for x in rows),'system_carbon_g':sum(float(x['total_carbon_g']) for x in rows),'system_IT_energy_kWh':sum(float(x['IT_energy_kWh']) for x in rows),'system_network_energy_kWh':sum(float(x['network_energy_kWh']) for x in rows)}
  call=[x for x in stages if x['scenario_id']==sid and x['policy']==policy and x['with_check']=='True'];unq=[x for x in call if x['quality_truth']=='False'];qual=[x for x in call if x['quality_truth']=='True'];faev=sum(x['verifier_pass']=='True' for x in unq);frev=sum(x['verifier_pass']=='False' for x in qual)
  checks.update({'verifier_calls':len(call),'unqualified_verifier_calls':len(unq),'false_accept_events':faev,'qualified_verifier_calls':len(qual),'false_reject_events':frev})
  if unq:need(close(s['empirical_FA_rate'],faev/len(unq)),'empirical FA rate mismatch')
  else:need(s['empirical_FA_rate']=='','FA rate NA mismatch')
  if qual:need(close(s['empirical_FR_rate'],frev/len(qual)),'empirical FR rate mismatch')
  else:need(s['empirical_FR_rate']=='','FR rate NA mismatch')
  for field,v in checks.items():need(close(s[field],v),f'summary mismatch {field} {sid}/{policy}')
  need(close(s['valid_rate_arrivals'],len(va)/n),'valid rate mismatch')
  need(close(s['cost_per_arrival'],checks['system_cost_units']/n),'cost/arrival mismatch')
  need(close(s['carbon_g_per_arrival'],checks['system_carbon_g']/n),'carbon/arrival mismatch')
  rsp=[float(x['response_s']) for x in sv]
  if rsp:
   need(close(s['mean_response_s_served'],sum(rsp)/len(rsp)) and close(s['p95_response_s_served'],percentile(rsp,.95)),'served response aggregate mismatch')
  else:need(s['mean_response_s_served']=='' and s['p95_response_s_served']=='','empty served response should be NA')
  if va:
   need(close(s['cost_per_valid'],checks['system_cost_units']/len(va)) and close(s['carbon_g_per_valid'],checks['system_carbon_g']/len(va)),'per-valid denominator mismatch')
  else:need(s['cost_per_valid']=='' and s['carbon_g_per_valid']=='','zero-valid cost/carbon should be NA')
 # Common-served is same cohort across all strategies.
 cmap={(x['scenario_id'],x['policy']):x for x in common}
 nested={}
 for x in ass:nested.setdefault((x['scenario_id'],x['policy']),{})[x['request_id']]=x
 for sid in {x['scenario_id'] for x in ass}:
  gp={p:nested[(sid,p)] for p in POLICIES}
  ids=set.intersection(*(set(k for k,v in d.items() if v['served']=='True') for d in gp.values()))
  for p in POLICIES:
   cohort=[gp[p][i] for i in ids];c=cmap[(sid,p)];need(int(c['N_common_served'])==len(ids),'common cohort size mismatch')
   if cohort:
    need(close(c['common_cost_per_request'],sum(float(x['total_cost_units']) for x in cohort)/len(ids)),'common cost mismatch')
    need(close(c['common_carbon_per_request'],sum(float(x['total_carbon_g']) for x in cohort)/len(ids)),'common carbon mismatch')
    need(close(c['common_valid_rate'],sum(x['valid']=='True' for x in cohort)/len(ids)),'common valid mismatch')
 return {'status':'passed','scope':'independent validation of source/output hashes, verifier transitions and FA/FR, delay/deadline feasibility, per-server non-overlap, source-CI carbon, energy/cost, response summaries/denominators, common-served cohort, and per-request local candidate tuple replay including eligible-candidate infeasibility','empirical_joint_policy_validated':False,'scenario_count':len(smap)//len(POLICIES),'assignment_rows':len(ass),'stage_rows':len(stages),'checked_server_intervals':checked_intervals,'objective_decisions_checked':objective_decisions_checked,'no_feasible_decisions_checked':no_feasible_decisions_checked,'audit_outcomes':len(audit),'limitations':['Synthetic quality/verifier/resource parameters only; no empirical calibration or deployment claim.','Candidate replay validates the declared local choice for each request/stage, not cross-request global optimality or whole-cascade optimality.']}
def atomic_json(path,obj):
 path=Path(path);tmp=path.with_name(path.name+'.tmp');tmp.write_text(json.dumps(obj,indent=2)+'\n');tmp.replace(path)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,default=ROOT/'results/cascade_joint_v5_conditional');ap.add_argument('--output',type=Path);a=ap.parse_args();out=a.input.resolve();manifest_path=out/'run_manifest.json';man=json.loads(manifest_path.read_text())
 report_path=(a.output.resolve() if a.output else out/'independent_validation_report.json')
 if out not in report_path.parents:raise SystemExit('validation report must be written inside the run output directory')
 # A rerun invalidates old success until every assertion succeeds again.
 man['status']='run_complete_pending_independent_checker';man.pop('independent_validation_report_sha256',None);atomic_json(manifest_path,man)
 report=check(out);text=json.dumps(report,indent=2)+'\n';tmp=report_path.with_name(report_path.name+'.tmp');tmp.write_text(text);tmp.replace(report_path)
 man=json.loads(manifest_path.read_text());man['status']='run_and_independent_checker_passed';man['independent_validation_report_file']=report_path.name;man['independent_validation_report_sha256']=sha(report_path);atomic_json(manifest_path,man)
 print(json.dumps(report,indent=2))
