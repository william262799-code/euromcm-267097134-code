# EuroMCM 2026 Problem λ — code and data

This repository contains the simulation source code and the public input data needed to reproduce the team's conditional-synthetic analyses. It does not contain the paper or large generated result ledgers. Model quality, request arrivals, verifier performance, service time, energy, price, capacity, PUE, and demand response are simulation assumptions; outputs must not be presented as real deployment measurements or verified savings.

## Run the simulations

Requires Python 3.10 or later. The code uses only the Python standard library. Run commands from the repository root:

```bash
python3 simulation/cascade_joint_v5_conditional.py
python3 simulation/independent_cascade_joint_v5_checker.py
python3 simulation/feedback_uncertainty_revision_experiment.py
python3 simulation/independent_feedback_mechanism_checker.py
python3 simulation/v5_robustness_rebound_subgroup_experiment.py
python3 simulation/independent_v5_robustness_checker.py
```

The runners create their output directories under `results/`; the checkers validate those generated files. Full output ledgers are not committed because some exceed GitHub's recommended file size.

## Input data

- `data_public/neso_2026_10_09_to_16/` contains the archived raw daily responses and processed regional forecast CSV from the NESO Carbon Intensity API. `manifest.json` records source URLs, time coverage, interpretation, license, and hashes. These are regional forecasts, not site-meter or marginal-emissions measurements.
- `data_public/azure_rtt_2026-07-30/uk_south_uk_west_p50.json` contains the published Azure regional P50 RTT reference used in one scenario; it is not application-level latency or network-energy data.
- `simulation/public_ci_joint_v5_scenarios.json` contains the synthetic model/action profiles and scenario definitions used by the runners.
- `analysis/fetch_neso_regional_week.py` documents the processing procedure for the archived NESO data. Re-running it contacts the public API and writes a new retrieval manifest.

The repository is intended to remain publicly accessible until EuroMCM announces the 2026 results.
