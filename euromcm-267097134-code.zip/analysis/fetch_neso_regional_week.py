"""Fetch a predeclared seven-day GB regional carbon-intensity case.

Only standard-library code is used. The API publishes *forecast* regional
intensity; these values must not be described as measured site or marginal
emissions.  The requested UTC interval is half-open.
"""

from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.request import Request, urlopen


START = datetime(2026, 10, 9, tzinfo=timezone.utc)
END = datetime(2026, 10, 16, tzinfo=timezone.utc)
ROOT = Path(__file__).resolve().parents[1] / "data_public" / "neso_2026_10_09_to_16"
BASE = "https://api.carbonintensity.org.uk/regional/intensity"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    by_key: dict[tuple[str, int], dict] = {}
    sources = []
    day = START
    while day < END:
        next_day = day + timedelta(days=1)
        start = day.strftime("%Y-%m-%dT%H:%MZ")
        finish = next_day.strftime("%Y-%m-%dT%H:%MZ")
        url = f"{BASE}/{start}/{finish}"
        request = Request(url, headers={"Accept": "application/json", "User-Agent": "EuroMCM-param-provenance/1.0"})
        with urlopen(request, timeout=30) as response:
            raw = response.read()
        obj = json.loads(raw)
        file = ROOT / f"raw_{day.date().isoformat()}.json"
        file.write_bytes(raw)
        sources.append({"url": url, "raw_file": file.name, "sha256": sha256(raw), "api_records": len(obj["data"])})
        for period in obj["data"]:
            # The API includes the preceding half-hour at interval boundaries.
            timestamp = datetime.fromisoformat(period["from"].replace("Z", "+00:00"))
            if not START <= timestamp < END:
                continue
            for region in period["regions"]:
                intensity = region["intensity"].get("forecast")
                if intensity is None:
                    raise ValueError(f"missing forecast: {timestamp}, {region['regionid']}")
                key = (period["from"], int(region["regionid"]))
                row = {"from_utc": period["from"], "to_utc": period["to"],
                       "regionid": region["regionid"], "region": region["shortname"],
                       "forecast_gco2_per_kwh": intensity,
                       "series_type": "regional_forecast_not_measured"}
                if key in by_key and by_key[key] != row:
                    raise ValueError(f"conflicting duplicate {key}")
                by_key[key] = row
        day = next_day

    rows = sorted(by_key.values(), key=lambda row: (row["from_utc"], int(row["regionid"])))
    times = {row["from_utc"] for row in rows}
    regions = {int(row["regionid"]) for row in rows}
    expected_periods = int((END - START).total_seconds() / 1800)
    if len(times) != expected_periods or len(rows) != expected_periods * len(regions):
        raise ValueError(f"incomplete series: {len(times)} periods, {len(regions)} regions, {len(rows)} rows")
    csv_path = ROOT / "regional_forecast.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    manifest = {
        "source": "National Energy System Operator (NESO) Carbon Intensity API",
        "documentation": "https://api.carbonintensity.org.uk/",
        "license": "CC BY 4.0 (as stated on API documentation)",
        "interpretation": "Regional forecast grid carbon intensity; not measured site PUE, marginal emissions, or actual data-center carbon accounting",
        "interval_utc_half_open": [START.isoformat(), END.isoformat()],
        "fetched_utc": datetime.now(timezone.utc).isoformat(),
        "sources": sources,
        "processed_file": csv_path.name,
        "processed_sha256": sha256(csv_path.read_bytes()),
        "periods": len(times), "regions": len(regions), "rows": len(rows),
    }
    (ROOT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"periods": len(times), "regions": len(regions), "rows": len(rows),
                      "csv_sha256": manifest["processed_sha256"]}))


if __name__ == "__main__":
    main()
